const API_BASE_URL = '/api';

export interface TargetsResponse {
  targets: Array<{
    gene: string;
    ml_score: number;
    tps: number;
    final_score: number;
    flags: string[];
    top_features: string[];
    summary: string;
  }>;
  total_count: number;
  returned_count: number;
}

export interface TargetDetailResponse {
  gene: string;
  scores: {
    ml_score: number;
    tps: number;
    final_score: number;
  };
  flags: string[];
  top_features: string[];
  summary: string;
  dossier: string;
  has_dossier: boolean;
}

export const fetchTopTargets = async (n: number = 10): Promise<TargetsResponse> => {
  const response = await fetch(`${API_BASE_URL}/targets/top?n=${n}`);
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return await response.json();
};

export const fetchTargetDetail = async (gene: string): Promise<TargetDetailResponse> => {
  const response = await fetch(`${API_BASE_URL}/targets/${gene}/card`);
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return await response.json();
};

export const searchTargets = async (query: string) => {
  const response = await fetch(`${API_BASE_URL}/targets/search?q=${query}`);
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return await response.json();
};