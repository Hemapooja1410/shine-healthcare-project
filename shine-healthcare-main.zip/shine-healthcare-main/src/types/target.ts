export interface Target {
  gene: string;
  ml_score: number;
  tps: number;
  final_score: number;
  flags: string[];
  top_features: string[];
  summary: string;
}

export interface TargetDetail {
  gene: string;
  scores: {
    ml_score: number;
    tps: number;
    final_score: number;
  };
  flags: string[];
  top_features: string[];
  summary: string;
  dossier: string;
  has_dossier: boolean;
}

export interface TargetsResponse {
  targets: Target[];
  total_count: number;
  returned_count: number;
}