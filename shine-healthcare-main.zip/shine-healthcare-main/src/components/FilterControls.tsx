import React from 'react';
import { Filter, X } from 'lucide-react';

interface FilterControlsProps {
  filters: {
    scoreThreshold: number;
    tractabilityClass: string;
    safetyLevel: string;
    evidenceTags: string[];
    tissueFilter: string;
  };
  onFilterChange: (filters: any) => void;
  totalTargets: number;
  filteredCount: number;
}

const FilterControls: React.FC<FilterControlsProps> = ({
  filters,
  onFilterChange,
  totalTargets,
  filteredCount
}) => {
  const evidenceOptions = [
    'gwas_coloc', 'eqtl', 'crispr', 'expression', 'genetic_evidence', 
    'omics_support', 'functional_screens', 'clinical_evidence'
  ];

  const tissueOptions = [
    'all', 'liver', 'brain', 'heart', 'lung', 'kidney', 'muscle', 'adipose'
  ];

  const updateFilter = (key: string, value: any) => {
    onFilterChange({ ...filters, [key]: value });
  };

  const toggleEvidenceTag = (tag: string) => {
    const newTags = filters.evidenceTags.includes(tag)
      ? filters.evidenceTags.filter(t => t !== tag)
      : [...filters.evidenceTags, tag];
    updateFilter('evidenceTags', newTags);
  };

  const clearAllFilters = () => {
    onFilterChange({
      scoreThreshold: 0.0,
      tractabilityClass: 'all',
      safetyLevel: 'all',
      evidenceTags: [],
      tissueFilter: 'all'
    });
  };

  const hasActiveFilters = filters.scoreThreshold > 0 || 
    filters.tractabilityClass !== 'all' || 
    filters.safetyLevel !== 'all' || 
    filters.evidenceTags.length > 0 || 
    filters.tissueFilter !== 'all';

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Filter className="h-5 w-5 text-slate-600" />
          <h3 className="text-lg font-semibold text-slate-900">Filter Targets</h3>
          <span className="text-sm text-slate-600">
            ({filteredCount} of {totalTargets} targets)
          </span>
        </div>
        {hasActiveFilters && (
          <button
            onClick={clearAllFilters}
            className="flex items-center px-3 py-1 text-sm text-slate-600 hover:text-slate-800 transition-colors"
          >
            <X className="h-4 w-4 mr-1" />
            Clear All
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        {/* Score Threshold */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Min Score: {filters.scoreThreshold.toFixed(2)}
          </label>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={filters.scoreThreshold}
            onChange={(e) => updateFilter('scoreThreshold', parseFloat(e.target.value))}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer slider"
          />
        </div>

        {/* Tractability Class */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Tractability
          </label>
          <select
            value={filters.tractabilityClass}
            onChange={(e) => updateFilter('tractabilityClass', e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Classes</option>
            <option value="druggable">Druggable</option>
            <option value="enzyme">Enzyme</option>
            <option value="gpcr">GPCR</option>
            <option value="kinase">Kinase</option>
            <option value="challenging">Challenging</option>
          </select>
        </div>

        {/* Safety Level */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Safety
          </label>
          <select
            value={filters.safetyLevel}
            onChange={(e) => updateFilter('safetyLevel', e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Levels</option>
            <option value="high">High Safety</option>
            <option value="medium">Medium Safety</option>
            <option value="concern">Safety Concerns</option>
          </select>
        </div>

        {/* Tissue Filter */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Tissue
          </label>
          <select
            value={filters.tissueFilter}
            onChange={(e) => updateFilter('tissueFilter', e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {tissueOptions.map(tissue => (
              <option key={tissue} value={tissue}>
                {tissue === 'all' ? 'All Tissues' : tissue.charAt(0).toUpperCase() + tissue.slice(1)}
              </option>
            ))}
          </select>
        </div>

        {/* Bulk Actions */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Actions
          </label>
          <div className="flex space-x-2">
            <button className="px-3 py-2 text-xs bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
              Export
            </button>
            <button className="px-3 py-2 text-xs bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition-colors">
              Select All
            </button>
          </div>
        </div>
      </div>

      {/* Evidence Tags */}
      <div className="mt-6">
        <label className="block text-sm font-medium text-slate-700 mb-3">
          Evidence Types ({filters.evidenceTags.length} selected)
        </label>
        <div className="flex flex-wrap gap-2">
          {evidenceOptions.map(tag => (
            <button
              key={tag}
              onClick={() => toggleEvidenceTag(tag)}
              className={`px-3 py-1 text-sm rounded-full border transition-colors ${
                filters.evidenceTags.includes(tag)
                  ? 'bg-blue-100 text-blue-800 border-blue-300'
                  : 'bg-slate-50 text-slate-600 border-slate-300 hover:bg-slate-100'
              }`}
            >
              {tag.replace(/_/g, ' ')}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FilterControls;