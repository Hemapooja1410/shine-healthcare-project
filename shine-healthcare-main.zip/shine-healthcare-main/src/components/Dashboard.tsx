import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import TopSummaryCards from './TopSummaryCards';
import RankedTargetsTable from './RankedTargetsTable';
import FilterControls from './FilterControls';
import { Target } from '../types/target';
import { fetchTopTargets } from '../services/api';

const Dashboard: React.FC = () => {
  const [targets, setTargets] = useState<Target[]>([]);
  const [filteredTargets, setFilteredTargets] = useState<Target[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState({
    scoreThreshold: 0.0,
    tractabilityClass: 'all',
    safetyLevel: 'all',
    evidenceTags: [] as string[],
    tissueFilter: 'all'
  });

  useEffect(() => {
    loadTargets();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [targets, filters]);

  const loadTargets = async () => {
    try {
      setLoading(true);
      const data = await fetchTopTargets(50);
      setTargets(data.targets);
    } catch (err) {
      setError('Failed to load targets. Please ensure the backend is running.');
      console.error('Error loading targets:', err);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = targets.filter(target => {
      // Score threshold
      if (target.final_score < filters.scoreThreshold) return false;
      
      // Tractability class
      if (filters.tractabilityClass !== 'all') {
        const hasClass = target.flags.some(flag => 
          flag.toLowerCase().includes(filters.tractabilityClass.toLowerCase())
        );
        if (!hasClass) return false;
      }
      
      // Safety level
      if (filters.safetyLevel !== 'all') {
        if (filters.safetyLevel === 'high' && target.flags.includes('SAFETY_CONCERN')) return false;
        if (filters.safetyLevel === 'concern' && !target.flags.includes('SAFETY_CONCERN')) return false;
      }
      
      // Evidence tags
      if (filters.evidenceTags.length > 0) {
        const hasEvidence = filters.evidenceTags.some(tag =>
          target.top_features.some(feature => 
            feature.toLowerCase().includes(tag.toLowerCase())
          )
        );
        if (!hasEvidence) return false;
      }
      
      return true;
    });
    
    setFilteredTargets(filtered);
  };

  const handleFilterChange = (newFilters: typeof filters) => {
    setFilters(newFilters);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <span className="ml-3 text-slate-600">Loading targets...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md mx-auto">
          <h3 className="text-red-800 font-medium">Connection Error</h3>
          <p className="text-red-600 text-sm mt-2">{error}</p>
          <button
            onClick={loadTargets}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-8"
    >
      {/* Hero Section */}
      <div className="text-center py-8">
        <motion.h2 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-4xl font-bold text-slate-900 mb-4"
        >
          AI-Powered Target Discovery
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-xl text-slate-600 max-w-3xl mx-auto"
        >
          Accelerate drug discovery with intelligent target identification, validation, 
          and ranking powered by machine learning and comprehensive biological evidence.
        </motion.p>
      </div>

      {/* Summary Cards */}
      <TopSummaryCards targets={targets} />

      {/* Filter Controls */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <FilterControls 
          filters={filters} 
          onFilterChange={handleFilterChange}
          totalTargets={targets.length}
          filteredCount={filteredTargets.length}
        />
      </motion.div>

      {/* Results Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <RankedTargetsTable targets={filteredTargets} />
      </motion.div>
    </motion.div>
  );
};

export default Dashboard;