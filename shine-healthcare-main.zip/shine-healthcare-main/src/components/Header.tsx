import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Target, Dna, Search, Settings, GitBranch, Download, Globe } from 'lucide-react';

const Header: React.FC = () => {
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [isDemoMode, setIsDemoMode] = useState(true);

  const isActive = (path: string) => {
    return location.pathname === path || (path === '/' && location.pathname === '/targets/top');
  };

  const navItems = [
    { path: '/', label: 'Dashboard', icon: Target },
    { path: '/pipeline', label: 'Pipeline', icon: GitBranch },
    { path: '/settings', label: 'Settings', icon: Settings },
  ];

  return (
    <header className="bg-white shadow-sm border-b border-slate-200">
      <div className="container mx-auto px-4 py-4">
        {/* Top Row */}
        <div className="flex items-center justify-between mb-4">
          <Link to="/" className="flex items-center space-x-3 hover:opacity-80 transition-opacity">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-blue-600 rounded-lg">
                <Target className="h-6 w-6 text-white" />
              </div>
              <Dna className="h-8 w-8 text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                AI Target Discovery
              </h1>
              <p className="text-sm text-slate-600">
                Intelligent protein target identification & validation platform
              </p>
            </div>
          </Link>

          <div className="flex items-center space-x-4">
            {/* Status Info */}
            <div className="text-right text-sm">
              <div className="text-slate-900 font-medium">Model v2.1.3</div>
              <div className="text-slate-600">Updated: 2025-01-15</div>
            </div>

            {/* Demo Mode Toggle */}
            <div className="flex items-center space-x-2">
              <Globe className="h-4 w-4 text-slate-600" />
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isDemoMode}
                  onChange={(e) => setIsDemoMode(e.target.checked)}
                  className="sr-only"
                />
                <div className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  isDemoMode ? 'bg-blue-600' : 'bg-slate-300'
                }`}>
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    isDemoMode ? 'translate-x-6' : 'translate-x-1'
                  }`} />
                </div>
                <span className="text-sm text-slate-700">
                  {isDemoMode ? 'Demo' : 'Live'}
                </span>
              </label>
            </div>

            {/* Export Button */}
            <button className="flex items-center px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </button>
          </div>
        </div>

        {/* Bottom Row */}
        <div className="flex items-center justify-between">
          {/* Navigation */}
          <nav className="flex space-x-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive(item.path)
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <item.icon className="w-4 h-4 mr-2" />
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Global Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search genes, pathways, diseases..."
              className="pl-10 pr-4 py-2 w-80 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;