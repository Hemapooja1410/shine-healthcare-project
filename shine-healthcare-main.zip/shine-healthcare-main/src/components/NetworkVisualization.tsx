import React from 'react';
import { Network, ExternalLink, Download } from 'lucide-react';

interface NetworkVisualizationProps {
  gene: string;
}

const NetworkVisualization: React.FC<NetworkVisualizationProps> = ({ gene }) => {
  // Mock network data
  const networkNodes = [
    { id: gene, label: gene, type: 'target', score: 0.87 },
    { id: 'EGFR', label: 'EGFR', type: 'known_target', score: 0.91 },
    { id: 'APP', label: 'APP', type: 'candidate', score: 0.79 },
    { id: 'BACE1', label: 'BACE1', type: 'candidate', score: 0.80 },
    { id: 'PCSK9', label: 'PCSK9', type: 'known_target', score: 0.90 },
  ];

  const interactions = [
    { source: gene, target: 'EGFR', type: 'protein_interaction', confidence: 0.85 },
    { source: gene, target: 'APP', type: 'pathway', confidence: 0.72 },
    { source: 'APP', target: 'BACE1', type: 'pathway', confidence: 0.91 },
    { source: 'EGFR', target: 'PCSK9', type: 'regulatory', confidence: 0.68 },
  ];

  const getNodeColor = (type: string) => {
    switch (type) {
      case 'target': return 'bg-blue-500';
      case 'known_target': return 'bg-green-500';
      case 'candidate': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getInteractionColor = (type: string) => {
    switch (type) {
      case 'protein_interaction': return 'border-blue-400';
      case 'pathway': return 'border-green-400';
      case 'regulatory': return 'border-purple-400';
      default: return 'border-gray-400';
    }
  };

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Network className="w-5 h-5 text-blue-600" />
          <h2 className="text-xl font-semibold text-slate-900">Protein-Protein Interaction Network</h2>
        </div>
        <div className="flex space-x-2">
          <button className="flex items-center px-3 py-2 text-sm bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition-colors">
            <ExternalLink className="w-4 h-4 mr-2" />
            STRING DB
          </button>
          <button className="flex items-center px-3 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
            <Download className="w-4 h-4 mr-2" />
            Export
          </button>
        </div>
      </div>

      {/* Network Visualization Placeholder */}
      <div className="bg-slate-50 border border-slate-200 rounded-lg p-8 mb-6">
        <div className="relative h-96 flex items-center justify-center">
          {/* Central Node */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className={`w-16 h-16 ${getNodeColor('target')} rounded-full flex items-center justify-center text-white font-bold shadow-lg`}>
              {gene}
            </div>
          </div>

          {/* Connected Nodes */}
          <div className="absolute top-8 left-1/2 transform -translate-x-1/2">
            <div className={`w-12 h-12 ${getNodeColor('known_target')} rounded-full flex items-center justify-center text-white text-sm font-medium shadow-md`}>
              EGFR
            </div>
          </div>
          <div className="absolute bottom-8 left-1/4">
            <div className={`w-12 h-12 ${getNodeColor('candidate')} rounded-full flex items-center justify-center text-white text-sm font-medium shadow-md`}>
              APP
            </div>
          </div>
          <div className="absolute bottom-8 right-1/4">
            <div className={`w-12 h-12 ${getNodeColor('candidate')} rounded-full flex items-center justify-center text-white text-sm font-medium shadow-md`}>
              BACE1
            </div>
          </div>
          <div className="absolute top-8 right-8">
            <div className={`w-12 h-12 ${getNodeColor('known_target')} rounded-full flex items-center justify-center text-white text-sm font-medium shadow-md`}>
              PCSK9
            </div>
          </div>

          {/* Connection Lines */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" 
                      refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#64748b" />
              </marker>
            </defs>
            <line x1="50%" y1="50%" x2="50%" y2="20%" stroke="#3b82f6" strokeWidth="2" markerEnd="url(#arrowhead)" />
            <line x1="50%" y1="50%" x2="25%" y2="80%" stroke="#10b981" strokeWidth="2" markerEnd="url(#arrowhead)" />
            <line x1="50%" y1="50%" x2="75%" y2="80%" stroke="#10b981" strokeWidth="2" markerEnd="url(#arrowhead)" />
            <line x1="50%" y1="50%" x2="85%" y2="20%" stroke="#8b5cf6" strokeWidth="2" markerEnd="url(#arrowhead)" />
          </svg>
        </div>
      </div>

      {/* Network Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <h4 className="font-medium text-slate-900 mb-2">Direct Interactions</h4>
          <div className="text-2xl font-bold text-blue-600">4</div>
          <p className="text-xs text-slate-600 mt-1">High-confidence connections</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <h4 className="font-medium text-slate-900 mb-2">Network Degree</h4>
          <div className="text-2xl font-bold text-green-600">12</div>
          <p className="text-xs text-slate-600 mt-1">Total network connections</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <h4 className="font-medium text-slate-900 mb-2">Pathway Overlap</h4>
          <div className="text-2xl font-bold text-purple-600">3</div>
          <p className="text-xs text-slate-600 mt-1">Shared biological pathways</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <h4 className="font-medium text-slate-900 mb-2">Centrality Score</h4>
          <div className="text-2xl font-bold text-orange-600">0.73</div>
          <p className="text-xs text-slate-600 mt-1">Network importance metric</p>
        </div>
      </div>

      {/* Interaction Details */}
      <div>
        <h3 className="text-lg font-medium text-slate-900 mb-4">Interaction Details</h3>
        <div className="space-y-3">
          {interactions.map((interaction, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <span className="font-mono text-sm font-medium">{interaction.source}</span>
                  <span className="text-slate-400">↔</span>
                  <span className="font-mono text-sm font-medium">{interaction.target}</span>
                </div>
                <span className={`px-2 py-1 text-xs rounded-full ${
                  interaction.type === 'protein_interaction' ? 'bg-blue-100 text-blue-700' :
                  interaction.type === 'pathway' ? 'bg-green-100 text-green-700' :
                  'bg-purple-100 text-purple-700'
                }`}>
                  {interaction.type.replace('_', ' ')}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-slate-600">Confidence:</span>
                <span className="font-mono text-sm font-medium">{interaction.confidence.toFixed(2)}</span>
                <div className="w-16 bg-slate-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${interaction.confidence * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="mt-6 pt-6 border-t border-slate-200">
        <h4 className="font-medium text-slate-900 mb-3">Legend</h4>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2">
            <div className={`w-4 h-4 ${getNodeColor('target')} rounded-full`}></div>
            <span className="text-sm text-slate-600">Current Target</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`w-4 h-4 ${getNodeColor('known_target')} rounded-full`}></div>
            <span className="text-sm text-slate-600">Known Target</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`w-4 h-4 ${getNodeColor('candidate')} rounded-full`}></div>
            <span className="text-sm text-slate-600">Candidate Target</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-1 bg-blue-400"></div>
            <span className="text-sm text-slate-600">Protein Interaction</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-1 bg-green-400"></div>
            <span className="text-sm text-slate-600">Pathway</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-1 bg-purple-400"></div>
            <span className="text-sm text-slate-600">Regulatory</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NetworkVisualization;