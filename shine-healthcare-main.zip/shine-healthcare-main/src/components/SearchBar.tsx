import React, { useState } from 'react';
import { Search, X } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ onSearch }) => {
  const [query, setQuery] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    onSearch(value);
  };

  const handleClear = () => {
    setQuery('');
    onSearch('');
  };

  return (
    <div className="relative">
      <div className="relative flex items-center">
        <Search className="absolute left-3 h-5 w-5 text-slate-400" />
        <input
          type="text"
          value={query}
          onChange={handleInputChange}
          placeholder="Search targets by gene name or description..."
          className="w-full pl-10 pr-10 py-3 border border-slate-300 rounded-lg 
                   focus:ring-2 focus:ring-blue-500 focus:border-transparent 
                   transition-all duration-200 text-slate-900 placeholder-slate-500
                   hover:border-slate-400"
        />
        {query && (
          <button
            onClick={handleClear}
            className="absolute right-3 p-1 hover:bg-slate-100 rounded-full 
                     transition-colors duration-200"
          >
            <X className="h-4 w-4 text-slate-400" />
          </button>
        )}
      </div>
      
      {/* Search suggestions could go here */}
      <div className="mt-2 flex flex-wrap gap-2">
        {['CYP2C19', 'EGFR', 'APP', 'BACE1'].map((suggestion) => (
          <button
            key={suggestion}
            onClick={() => {
              setQuery(suggestion);
              onSearch(suggestion);
            }}
            className="px-3 py-1 text-sm bg-blue-50 text-blue-700 rounded-full 
                     hover:bg-blue-100 transition-colors duration-200"
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SearchBar;