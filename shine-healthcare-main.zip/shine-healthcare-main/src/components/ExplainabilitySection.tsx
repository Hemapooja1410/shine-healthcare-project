import React from 'react';
import { BarChart3, TrendingUp, Info } from 'lucide-react';
import { TargetDetail } from '../types/target';

interface ExplainabilitySectionProps {
  target: TargetDetail;
}

const ExplainabilitySection: React.FC<ExplainabilitySectionProps> = ({ target }) => {
  // Mock SHAP values for demonstration
  const shapValues = [
    { feature: 'genetic_evidence', value: 0.35, description: 'Strong GWAS colocalization signals' },
    { feature: 'expression_data', value: 0.25, description: 'Consistent tissue-specific expression' },
    { feature: 'functional_screens', value: 0.20, description: 'CRISPR knockout validation' },
    { feature: 'safety_profile', value: 0.15, description: 'Favorable toxicity predictions' },
    { feature: 'druggability', value: 0.12, description: 'Tractable protein structure' },
    { feature: 'clinical_evidence', value: 0.08, description: 'Existing therapeutic precedent' },
    { feature: 'pathway_analysis', value: -0.05, description: 'Limited pathway connectivity' },
    { feature: 'tissue_specificity', value: -0.10, description: 'Broad expression pattern' },
  ];

  const maxAbsValue = Math.max(...shapValues.map(s => Math.abs(s.value)));

  return (
    <div className="p-8">
      <div className="flex items-center space-x-2 mb-6">
        <BarChart3 className="w-5 h-5 text-blue-600" />
        <h2 className="text-xl font-semibold text-slate-900">AI Model Explainability</h2>
      </div>

      {/* Model Interpretation Summary */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
        <h3 className="font-semibold text-blue-900 mb-2">Model Interpretation</h3>
        <p className="text-blue-800 text-sm leading-relaxed">
          The high confidence score for {target.gene} is primarily driven by strong genetic validation 
          (35% contribution) and consistent expression evidence (25% contribution). The model weighs 
          functional validation and safety profiles as key supporting factors.
        </p>
      </div>

      {/* Global Feature Importance */}
      <div className="mb-8">
        <h3 className="text-lg font-medium text-slate-900 mb-4">Feature Importance (SHAP Values)</h3>
        <div className="space-y-3">
          {shapValues.map((item, index) => (
            <div key={item.feature} className="flex items-center space-x-4">
              <div className="w-32 text-sm text-slate-700 font-medium">
                {item.feature.replace(/_/g, ' ')}
              </div>
              <div className="flex-1 relative">
                <div className="h-6 bg-slate-100 rounded-full relative overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      item.value >= 0 ? 'bg-green-500' : 'bg-red-500'
                    }`}
                    style={{
                      width: `${(Math.abs(item.value) / maxAbsValue) * 100}%`,
                      marginLeft: item.value < 0 ? `${100 - (Math.abs(item.value) / maxAbsValue) * 100}%` : '0'
                    }}
                  />
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xs font-medium text-slate-700">
                    {item.value > 0 ? '+' : ''}{item.value.toFixed(2)}
                  </span>
                </div>
              </div>
              <div className="w-8 flex justify-center">
                <div className="group relative">
                  <Info className="w-4 h-4 text-slate-400 hover:text-slate-600 cursor-help" />
                  <div className="absolute bottom-full right-0 mb-2 w-64 p-2 bg-slate-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                    {item.description}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Waterfall Chart Placeholder */}
      <div className="mb-8">
        <h3 className="text-lg font-medium text-slate-900 mb-4">Decision Waterfall</h3>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-6 text-center">
          <TrendingUp className="w-12 h-12 text-slate-400 mx-auto mb-2" />
          <p className="text-slate-600 text-sm">
            Interactive waterfall chart showing how each feature contributes to the final score
          </p>
          <p className="text-slate-500 text-xs mt-1">
            Base score: 0.45 → Final score: {target.scores.final_score.toFixed(3)}
          </p>
        </div>
      </div>

      {/* Model Confidence Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <h4 className="font-medium text-slate-900 mb-2">Prediction Confidence</h4>
          <div className="text-2xl font-bold text-blue-600">{(target.scores.ml_score * 100).toFixed(1)}%</div>
          <p className="text-xs text-slate-600 mt-1">Model certainty in prediction</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <h4 className="font-medium text-slate-900 mb-2">Feature Coverage</h4>
          <div className="text-2xl font-bold text-green-600">87%</div>
          <p className="text-xs text-slate-600 mt-1">Available evidence features</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <h4 className="font-medium text-slate-900 mb-2">Model Version</h4>
          <div className="text-lg font-bold text-slate-700">v2.1.3</div>
          <p className="text-xs text-slate-600 mt-1">Trained on 50K+ targets</p>
        </div>
      </div>

      {/* Download Links */}
      <div className="mt-8 pt-6 border-t border-slate-200">
        <h4 className="font-medium text-slate-900 mb-3">Export Explainability Data</h4>
        <div className="flex space-x-3">
          <button className="px-4 py-2 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors">
            Download SHAP Values (CSV)
          </button>
          <button className="px-4 py-2 bg-slate-100 text-slate-700 text-sm rounded-md hover:bg-slate-200 transition-colors">
            Export Waterfall Chart (PNG)
          </button>
          <button className="px-4 py-2 bg-slate-100 text-slate-700 text-sm rounded-md hover:bg-slate-200 transition-colors">
            Model Card (PDF)
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExplainabilitySection;