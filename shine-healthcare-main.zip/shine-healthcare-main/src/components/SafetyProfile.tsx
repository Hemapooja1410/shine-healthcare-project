import React from "react";
import { Shield, AlertTriangle, CheckCircle, Heart, Brain } from "lucide-react";
import { TargetDetail } from "../types/target";

interface SafetyProfileProps {
  target: TargetDetail;
}

const SafetyProfile: React.FC<SafetyProfileProps> = ({ target }) => {
  // Mock safety data
  const tissueExpression = [
    {
      tissue: "Liver",
      expression: "High",
      icon: Heart,
      risk: "Medium",
      color: "yellow",
    },
    {
      tissue: "Heart",
      expression: "Low",
      icon: Heart,
      risk: "Low",
      color: "green",
    },
    {
      tissue: "Brain",
      expression: "Medium",
      icon: Brain,
      risk: "High",
      color: "red",
    },
    {
      tissue: "Kidney",
      expression: "Medium",
      icon: Shield,
      risk: "Medium",
      color: "yellow",
    },
    {
      tissue: "Lung",
      expression: "Low",
      icon: Shield,
      risk: "Low",
      color: "green",
    },
  ];

  const safetyMetrics = [
    {
      metric: "pLI Score",
      value: "0.23",
      description: "Probability of loss-of-function intolerance",
      status: "safe",
    },
    {
      metric: "LOEUF",
      value: "0.87",
      description: "Loss-of-function observed/expected upper bound",
      status: "safe",
    },
    {
      metric: "Haploinsufficiency",
      value: "Low",
      description: "Sensitivity to gene dosage reduction",
      status: "safe",
    },
    {
      metric: "Essential Gene",
      value: "No",
      description: "Required for cell viability",
      status: "safe",
    },
  ];

  const adverseEvents = [
    {
      event: "Hepatotoxicity",
      frequency: "Rare",
      severity: "Moderate",
      evidence: "Case reports",
    },
    {
      event: "Drug interactions",
      frequency: "Common",
      severity: "Mild",
      evidence: "Clinical studies",
    },
    {
      event: "Metabolic effects",
      frequency: "Uncommon",
      severity: "Mild",
      evidence: "Preclinical",
    },
  ];

  const getRiskColor = (color: string) => {
    switch (color) {
      case "green":
        return "bg-green-100 text-green-800 border-green-200";
      case "yellow":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "red":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "safe":
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case "concern":
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case "risk":
        return <AlertTriangle className="w-4 h-4 text-red-600" />;
      default:
        return <Shield className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <div className="p-8">
      <div className="flex items-center space-x-2 mb-6">
        <Shield className="w-5 h-5 text-blue-600" />
        <h2 className="text-xl font-semibold text-slate-900">
          Safety Profile Assessment
        </h2>
      </div>

      {/* Overall Safety Summary */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-8">
        <div className="flex items-center space-x-2 mb-2">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <h3 className="font-semibold text-green-900">
            Overall Safety Assessment: Favorable
          </h3>
        </div>
        <p className="text-green-800 text-sm">
          {target.gene} shows a generally favorable safety profile with low
          probability of loss-of-function intolerance and manageable
          tissue-specific risks. Primary considerations include hepatic
          expression and potential drug-drug interactions.
        </p>
      </div>

      {/* Tissue Expression Heatmap */}
      <div className="mb-8">
        <h3 className="text-lg font-medium text-slate-900 mb-4">
          Tissue Expression & Risk Assessment
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tissueExpression.map((item) => (
            <div
              key={item.tissue}
              className="bg-white border border-slate-200 rounded-lg p-4"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <item.icon className="w-5 h-5 text-slate-600" />
                  <span className="font-medium text-slate-900">
                    {item.tissue}
                  </span>
                </div>
                <span
                  className={`px-2 py-1 text-xs rounded-full border ${getRiskColor(
                    item.color
                  )}`}
                >
                  {item.risk} Risk
                </span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Expression:</span>
                  <span className="font-medium">{item.expression}</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-300 ${
                      item.expression === "High"
                        ? "bg-red-500 w-full"
                        : item.expression === "Medium"
                        ? "bg-yellow-500 w-2/3"
                        : "bg-green-500 w-1/3"
                    }`}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Safety Metrics */}
      <div className="mb-8">
        <h3 className="text-lg font-medium text-slate-900 mb-4">
          Genetic Safety Metrics
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {safetyMetrics.map((metric) => (
            <div
              key={metric.metric}
              className="bg-white border border-slate-200 rounded-lg p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-slate-900">{metric.metric}</h4>
                {getStatusIcon(metric.status)}
              </div>
              <div className="text-2xl font-bold text-slate-700 mb-1">
                {metric.value}
              </div>
              <p className="text-sm text-slate-600">{metric.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Adverse Events */}
      <div className="mb-8">
        <h3 className="text-lg font-medium text-slate-900 mb-4">
          Potential Adverse Events
        </h3>
        <div className="space-y-3">
          {adverseEvents.map((event, index) => (
            <div
              key={index}
              className="bg-white border border-slate-200 rounded-lg p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-slate-900">{event.event}</h4>
                <div className="flex space-x-2">
                  <span
                    className={`px-2 py-1 text-xs rounded-full ${
                      event.frequency === "Common"
                        ? "bg-red-100 text-red-700"
                        : event.frequency === "Uncommon"
                        ? "bg-yellow-100 text-yellow-700"
                        : "bg-green-100 text-green-700"
                    }`}
                  >
                    {event.frequency}
                  </span>
                  <span
                    className={`px-2 py-1 text-xs rounded-full ${
                      event.severity === "Severe"
                        ? "bg-red-100 text-red-700"
                        : event.severity === "Moderate"
                        ? "bg-yellow-100 text-yellow-700"
                        : "bg-green-100 text-green-700"
                    }`}
                  >
                    {event.severity}
                  </span>
                </div>
              </div>
              <p className="text-sm text-slate-600">
                Evidence: {event.evidence}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Risk Mitigation Strategies */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="font-semibold text-blue-900 mb-4">
          Risk Mitigation Strategies
        </h3>
        <div className="space-y-3">
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <div>
              <h4 className="font-medium text-blue-900">
                Biomarker Monitoring
              </h4>
              <p className="text-sm text-blue-800">
                Implement liver function monitoring and pharmacogenetic testing
                for CYP2C19 variants
              </p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <div>
              <h4 className="font-medium text-blue-900">
                Drug Interaction Management
              </h4>
              <p className="text-sm text-blue-800">
                Establish comprehensive drug interaction screening protocols and
                dosing guidelines
              </p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <div>
              <h4 className="font-medium text-blue-900">
                Patient Stratification
              </h4>
              <p className="text-sm text-blue-800">
                Use genetic testing to identify patients at higher risk for
                adverse events
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SafetyProfile;
