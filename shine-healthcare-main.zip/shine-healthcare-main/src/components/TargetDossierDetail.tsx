import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Share2,
  ExternalLink,
  AlertCircle,
  CheckCircle,
  Shield,
  Target,
  BarChart3,
  Microscope,
  Activity,
  FileText,
  Printer,
  Dna,
  Brain,
  Info,
} from "lucide-react";

interface DossierTarget {
  gene: string;
  finalScore: number;
  causality: "High" | "Moderate" | "Low";
  tractability: "Druggable" | "Challenging" | "Undruggable";
  safety: "Safe" | "Concern" | "Unknown";
  summary: string;
  rank: number;
  confidence: number;
  keyFeatures: string[];
  geneticEvidence: {
    gwasStudies: Array<{ study: string; pValue: number; effect: string }>;
    eqtlEvidence: Array<{ tissue: string; pValue: number; direction: string }>;
    mendelianRandomization: { pValue: number; odds: number };
  };
  omicsSupport: {
    bulkRnaSeq: { logFoldChange: number; pValue: number; tissues: string[] };
    singleCellRnaSeq: {
      cellType: string;
      enrichment: number;
      specificity: string;
    };
    proteomics: { foldChange: number; confidence: string };
  };
  functionalValidation: {
    crisprKnockout: { effectSize: number; pValue: number; phenotype: string };
    pharmacologicalInhibition: {
      ic50: number;
      selectivity: number;
      mechanism: string;
    };
    animalModels: Array<{ model: string; phenotype: string; severity: string }>;
  };
  safetyConcerns: {
    tissueExpression: Array<{ tissue: string; level: string; risk: string }>;
    toxicitySignals: Array<{
      signal: string;
      severity: string;
      evidence: string;
    }>;
    drugInteractions: Array<{
      drug: string;
      interaction: string;
      severity: string;
    }>;
  };
  tractabilityData: {
    drugClass: string;
    smallMoleculeReadiness: number;
    antibodyReadiness: number;
    knownBindingSites: number;
    structuralInfo: string;
  };
  explainabilityData: {
    topFeatures: Array<{
      feature: string;
      importance: number;
      direction: string;
    }>;
    shap: Array<{ category: string; score: number; confidence: number }>;
    modelVersion: string;
  };
}

const TargetDossierDetail: React.FC = () => {
  const { gene } = useParams<{ gene: string }>();
  const [target, setTarget] = useState<DossierTarget | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] = useState("overview");

  // Mock detailed data - replace with API call
  const mockDossierData: Record<string, DossierTarget> = {
    CYP2C19: {
      gene: "CYP2C19",
      finalScore: 0.943,
      causality: "High",
      tractability: "Druggable",
      safety: "Safe",
      summary:
        "Critical enzyme in drug metabolism with well-established pharmacogenetic markers and therapeutic relevance.",
      rank: 1,
      confidence: 0.92,
      keyFeatures: [
        "Drug Metabolism",
        "Pharmacogenetics",
        "Liver Expression",
        "Clinical Variants",
      ],
      geneticEvidence: {
        gwasStudies: [
          {
            study: "Drug Response GWAS",
            pValue: 2.3e-8,
            effect: "Increased metabolism",
          },
          {
            study: "Cardiovascular Outcomes",
            pValue: 1.1e-6,
            effect: "Protective",
          },
          {
            study: "Liver Function",
            pValue: 4.7e-5,
            effect: "Enhanced clearance",
          },
        ],
        eqtlEvidence: [
          { tissue: "Liver", pValue: 1.2e-12, direction: "Upregulated" },
          { tissue: "Intestine", pValue: 3.4e-8, direction: "Upregulated" },
          { tissue: "Kidney", pValue: 7.1e-6, direction: "Moderate" },
        ],
        mendelianRandomization: { pValue: 1.5e-4, odds: 1.8 },
      },
      omicsSupport: {
        bulkRnaSeq: {
          logFoldChange: 1.8,
          pValue: 3.2e-4,
          tissues: ["Liver", "Heart"],
        },
        singleCellRnaSeq: {
          cellType: "Hepatocytes",
          enrichment: 2.1,
          specificity: "High",
        },
        proteomics: { foldChange: 1.6, confidence: "High" },
      },
      functionalValidation: {
        crisprKnockout: {
          effectSize: 65,
          pValue: 1.2e-6,
          phenotype: "Reduced drug metabolism",
        },
        pharmacologicalInhibition: {
          ic50: 2.3,
          selectivity: 100,
          mechanism: "Competitive inhibition",
        },
        animalModels: [
          {
            model: "Knockout mice",
            phenotype: "Altered drug clearance",
            severity: "Moderate",
          },
          {
            model: "Humanized mice",
            phenotype: "Pharmacokinetic changes",
            severity: "Significant",
          },
        ],
      },
      safetyConcerns: {
        tissueExpression: [
          { tissue: "Liver", level: "High", risk: "Low" },
          { tissue: "Brain", level: "Low", risk: "Minimal" },
          { tissue: "Heart", level: "Moderate", risk: "Low" },
        ],
        toxicitySignals: [
          {
            signal: "Hepatotoxicity",
            severity: "Low",
            evidence: "Clinical studies",
          },
          {
            signal: "Drug interactions",
            severity: "Moderate",
            evidence: "Pharmacovigilance",
          },
        ],
        drugInteractions: [
          {
            drug: "Clopidogrel",
            interaction: "Reduced efficacy",
            severity: "High",
          },
          {
            drug: "Omeprazole",
            interaction: "CYP inhibition",
            severity: "Moderate",
          },
        ],
      },
      tractabilityData: {
        drugClass: "Small molecule modulators",
        smallMoleculeReadiness: 0.89,
        antibodyReadiness: 0.23,
        knownBindingSites: 3,
        structuralInfo: "Crystal structure available",
      },
      explainabilityData: {
        topFeatures: [
          {
            feature: "Liver expression",
            importance: 0.24,
            direction: "Positive",
          },
          {
            feature: "Drug metabolism pathway",
            importance: 0.19,
            direction: "Positive",
          },
          {
            feature: "Pharmacogenetic variants",
            importance: 0.16,
            direction: "Positive",
          },
          {
            feature: "Clinical validation",
            importance: 0.14,
            direction: "Positive",
          },
          {
            feature: "Safety profile",
            importance: 0.12,
            direction: "Positive",
          },
        ],
        shap: [
          { category: "Genetic Evidence", score: 0.31, confidence: 0.94 },
          { category: "Expression Data", score: 0.28, confidence: 0.89 },
          { category: "Functional Studies", score: 0.22, confidence: 0.87 },
          { category: "Safety Profile", score: 0.19, confidence: 0.91 },
        ],
        modelVersion: "DrugTargetAI-v2.1.3",
      },
    },
  };

  useEffect(() => {
    if (gene) {
      // Simulate API call
      setTimeout(() => {
        setTarget(mockDossierData[gene] || null);
        setLoading(false);
      }, 500);
    }
  }, [gene]);

  const exportToPDF = () => {
    window.print();
  };

  const shareTarget = () => {
    if (navigator.share) {
      navigator.share({
        title: `${target?.gene} Target Dossier`,
        text: target?.summary,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert("Link copied to clipboard!");
    }
  };

  const sections = [
    { id: "overview", label: "Overview", icon: Target },
    { id: "genetic", label: "Genetic Evidence", icon: Dna },
    { id: "omics", label: "Omics Support", icon: BarChart3 },
    { id: "functional", label: "Functional Validation", icon: Microscope },
    { id: "safety", label: "Safety Concerns", icon: Shield },
    { id: "tractability", label: "Tractability", icon: Activity },
    { id: "explainability", label: "AI Explainability", icon: Brain },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <span className="ml-3 text-slate-600">Loading target dossier...</span>
      </div>
    );
  }

  if (!target) {
    return (
      <div className="text-center py-12">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md mx-auto">
          <h3 className="text-red-800 font-medium">Target Not Found</h3>
          <p className="text-red-600 text-sm mt-2">
            The requested target dossier could not be found.
          </p>
          <Link
            to="/targets/top"
            className="mt-4 inline-block px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Back to Target List
          </Link>
        </div>
      </div>
    );
  }

  const getScoreColor = (score: number) => {
    if (score >= 0.9) return "text-green-600 bg-green-50 border-green-200";
    if (score >= 0.8) return "text-blue-600 bg-blue-50 border-blue-200";
    if (score >= 0.7) return "text-yellow-600 bg-yellow-50 border-yellow-200";
    return "text-gray-600 bg-gray-50 border-gray-200";
  };

  const getConfidenceBadge = (causality: string) => {
    if (causality === "High") {
      return (
        <span className="inline-flex items-center px-3 py-1 text-sm font-medium bg-green-100 text-green-800 rounded-full">
          <CheckCircle className="w-4 h-4 mr-2" />
          High Confidence
        </span>
      );
    } else if (causality === "Moderate") {
      return (
        <span className="inline-flex items-center px-3 py-1 text-sm font-medium bg-yellow-100 text-yellow-800 rounded-full">
          <AlertCircle className="w-4 h-4 mr-2" />
          Moderate Confidence
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-3 py-1 text-sm font-medium bg-gray-100 text-gray-800 rounded-full">
        <Shield className="w-4 h-4 mr-2" />
        Low Confidence
      </span>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-7xl mx-auto p-6"
    >
      {/* Header */}
      <div className="mb-8">
        <Link
          to="/targets/top"
          className="inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Target List
        </Link>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center space-x-4 mb-4">
                <h1 className="text-4xl font-bold text-slate-900 font-mono">
                  {target.gene}
                </h1>
                {getConfidenceBadge(target.causality)}
                <span className="text-sm text-slate-600">
                  Rank #{target.rank}
                </span>
              </div>

              {/* Identifiers */}
              <div className="flex items-center space-x-4 mb-4 text-sm text-slate-600">
                <span>HGNC: HGNC:2620</span>
                <span>Ensembl: ENSG00000155657</span>
                <span>UniProt: P33261</span>
              </div>

              {/* AI Summary */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <h3 className="font-semibold text-blue-900 mb-2">
                  AI-Generated Summary
                </h3>
                <p className="text-blue-800 leading-relaxed">
                  {target.summary}
                </p>
              </div>

              {/* Score Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div
                  className={`p-4 rounded-lg border ${getScoreColor(
                    target.finalScore
                  )}`}
                >
                  <div className="text-2xl font-bold">
                    {target.finalScore.toFixed(3)}
                  </div>
                  <div className="text-sm opacity-80">Final Score</div>
                  <div className="w-full bg-white bg-opacity-50 rounded-full h-2 mt-2">
                    <div
                      className="bg-current h-2 rounded-full transition-all duration-300"
                      style={{ width: `${target.finalScore * 100}%` }}
                    />
                  </div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-2xl font-bold text-slate-700">
                    {(target.confidence * 100).toFixed(0)}%
                  </div>
                  <div className="text-sm text-slate-600">Confidence</div>
                  <div className="w-full bg-slate-200 rounded-full h-2 mt-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${target.confidence * 100}%` }}
                    />
                  </div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-2xl font-bold text-slate-700">
                    {target.tractability}
                  </div>
                  <div className="text-sm text-slate-600">Tractability</div>
                  <div className="flex items-center mt-2">
                    <span
                      className={`px-2 py-1 text-xs rounded ${
                        target.tractability === "Druggable"
                          ? "bg-green-100 text-green-700"
                          : target.tractability === "Challenging"
                          ? "bg-orange-100 text-orange-700"
                          : "bg-red-100 text-red-700"
                      }`}
                    >
                      {target.tractability}
                    </span>
                  </div>
                </div>
              </div>

              {/* Key Features */}
              <div>
                <h3 className="text-sm font-semibold text-slate-700 mb-2">
                  Key Evidence Features:
                </h3>
                <div className="flex flex-wrap gap-2">
                  {target.keyFeatures.map((feature) => (
                    <span
                      key={feature}
                      className="px-2 py-1 text-xs bg-green-50 text-green-700 rounded border border-green-200"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col space-y-3 ml-6">
              <button
                onClick={exportToPDF}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                <Printer className="w-4 h-4 mr-2" />
                Print PDF
              </button>
              <button
                onClick={shareTarget}
                className="flex items-center px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition-colors"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </button>
              <button className="flex items-center px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition-colors">
                <ExternalLink className="w-4 h-4 mr-2" />
                UniProt
              </button>
              <button className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                <FileText className="w-4 h-4 mr-2" />
                Add to Pipeline
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Section Navigation */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 sticky top-4">
            <h3 className="font-semibold text-slate-900 mb-4">Sections</h3>
            <nav className="space-y-1">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center px-3 py-2 text-sm rounded-md transition-colors ${
                    activeSection === section.id
                      ? "bg-blue-100 text-blue-700"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <section.icon className="w-4 h-4 mr-3" />
                  {section.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-xl shadow-sm border border-slate-200"
          >
            {activeSection === "overview" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Target className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Target Overview
                  </h2>
                </div>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-slate-50 rounded-lg p-4">
                      <h3 className="font-medium text-slate-900 mb-3">
                        Basic Information
                      </h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-600">Gene Symbol:</span>
                          <span className="font-mono">{target.gene}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Final Score:</span>
                          <span className="font-mono">
                            {target.finalScore.toFixed(3)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Confidence:</span>
                          <span className="font-mono">
                            {(target.confidence * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Ranking:</span>
                          <span>#{target.rank}</span>
                        </div>
                      </div>
                    </div>
                    <div className="bg-slate-50 rounded-lg p-4">
                      <h3 className="font-medium text-slate-900 mb-3">
                        Assessment Summary
                      </h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-600">Causality:</span>
                          <span
                            className={`px-2 py-1 rounded text-xs ${
                              target.causality === "High"
                                ? "bg-green-100 text-green-700"
                                : target.causality === "Moderate"
                                ? "bg-yellow-100 text-yellow-700"
                                : "bg-gray-100 text-gray-700"
                            }`}
                          >
                            {target.causality}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Tractability:</span>
                          <span
                            className={`px-2 py-1 rounded text-xs ${
                              target.tractability === "Druggable"
                                ? "bg-green-100 text-green-700"
                                : target.tractability === "Challenging"
                                ? "bg-orange-100 text-orange-700"
                                : "bg-red-100 text-red-700"
                            }`}
                          >
                            {target.tractability}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Safety:</span>
                          <span
                            className={`px-2 py-1 rounded text-xs ${
                              target.safety === "Safe"
                                ? "bg-green-100 text-green-700"
                                : target.safety === "Concern"
                                ? "bg-red-100 text-red-700"
                                : "bg-gray-100 text-gray-700"
                            }`}
                          >
                            {target.safety}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h3 className="font-medium text-blue-900 mb-2">Summary</h3>
                    <p className="text-blue-800 text-sm leading-relaxed">
                      {target.summary}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "genetic" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Dna className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Genetic Evidence
                  </h2>
                </div>
                <div className="space-y-6">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      GWAS Studies
                    </h3>
                    <div className="space-y-3">
                      {target.geneticEvidence.gwasStudies.map(
                        (study, index) => (
                          <div
                            key={index}
                            className="bg-white p-3 rounded border"
                          >
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-medium text-sm">
                                {study.study}
                              </span>
                              <span className="text-xs font-mono bg-blue-100 text-blue-700 px-2 py-1 rounded">
                                P = {study.pValue.toExponential(1)}
                              </span>
                            </div>
                            <p className="text-sm text-slate-600">
                              {study.effect}
                            </p>
                          </div>
                        )
                      )}
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      eQTL Evidence
                    </h3>
                    <div className="space-y-2">
                      {target.geneticEvidence.eqtlEvidence.map(
                        (eqtl, index) => (
                          <div
                            key={index}
                            className="flex justify-between items-center bg-white p-3 rounded border"
                          >
                            <div>
                              <span className="font-medium text-sm">
                                {eqtl.tissue}
                              </span>
                              <span className="ml-2 text-sm text-slate-600">
                                ({eqtl.direction})
                              </span>
                            </div>
                            <span className="text-xs font-mono bg-green-100 text-green-700 px-2 py-1 rounded">
                              P = {eqtl.pValue.toExponential(1)}
                            </span>
                          </div>
                        )
                      )}
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Mendelian Randomization
                    </h3>
                    <div className="bg-white p-3 rounded border">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-slate-600">P-value:</span>
                          <span className="ml-2 font-mono">
                            {target.geneticEvidence.mendelianRandomization.pValue.toExponential(
                              1
                            )}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-600">Odds Ratio:</span>
                          <span className="ml-2 font-mono">
                            {target.geneticEvidence.mendelianRandomization.odds}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "omics" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Omics Support
                  </h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Bulk RNA-seq
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-600">
                          Log2 Fold Change:
                        </span>
                        <span className="font-mono text-green-600">
                          +{target.omicsSupport.bulkRnaSeq.logFoldChange}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">P-value:</span>
                        <span className="font-mono">
                          {target.omicsSupport.bulkRnaSeq.pValue.toExponential(
                            1
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Tissues:</span>
                        <span className="text-sm">
                          {target.omicsSupport.bulkRnaSeq.tissues.join(", ")}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Single-cell RNA-seq
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-600">Cell Type:</span>
                        <span>
                          {target.omicsSupport.singleCellRnaSeq.cellType}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Enrichment:</span>
                        <span className="font-mono">
                          {target.omicsSupport.singleCellRnaSeq.enrichment}x
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Specificity:</span>
                        <span>
                          {target.omicsSupport.singleCellRnaSeq.specificity}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-4 md:col-span-2">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Proteomics
                    </h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-600">Fold Change:</span>
                        <span className="font-mono text-blue-600">
                          {target.omicsSupport.proteomics.foldChange}x
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Confidence:</span>
                        <span>{target.omicsSupport.proteomics.confidence}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "functional" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Microscope className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Functional Validation
                  </h2>
                </div>
                <div className="space-y-6">
                  <div className="border border-slate-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-medium text-slate-900">
                        CRISPR Knockout
                      </h3>
                      <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">
                        Validated
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 mb-3">
                      {target.functionalValidation.crisprKnockout.phenotype}
                    </p>
                    <div className="grid grid-cols-2 gap-4 text-xs text-slate-500">
                      <div>
                        Effect size:{" "}
                        {target.functionalValidation.crisprKnockout.effectSize}%
                        reduction
                      </div>
                      <div>
                        P-value:{" "}
                        {target.functionalValidation.crisprKnockout.pValue.toExponential(
                          1
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="border border-slate-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-medium text-slate-900">
                        Pharmacological Inhibition
                      </h3>
                      <span className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded">
                        Confirmed
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 mb-3">
                      {
                        target.functionalValidation.pharmacologicalInhibition
                          .mechanism
                      }
                    </p>
                    <div className="grid grid-cols-2 gap-4 text-xs text-slate-500">
                      <div>
                        IC50:{" "}
                        {
                          target.functionalValidation.pharmacologicalInhibition
                            .ic50
                        }{" "}
                        μM
                      </div>
                      <div>
                        Selectivity: &gt;
                        {
                          target.functionalValidation.pharmacologicalInhibition
                            .selectivity
                        }
                        x
                      </div>
                    </div>
                  </div>

                  <div className="border border-slate-200 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Animal Models
                    </h3>
                    <div className="space-y-2">
                      {target.functionalValidation.animalModels.map(
                        (model, index) => (
                          <div key={index} className="bg-slate-50 p-3 rounded">
                            <div className="flex justify-between items-start mb-1">
                              <span className="font-medium text-sm">
                                {model.model}
                              </span>
                              <span
                                className={`px-2 py-1 text-xs rounded ${
                                  model.severity === "Significant"
                                    ? "bg-red-100 text-red-700"
                                    : model.severity === "Moderate"
                                    ? "bg-yellow-100 text-yellow-700"
                                    : "bg-green-100 text-green-700"
                                }`}
                              >
                                {model.severity}
                              </span>
                            </div>
                            <p className="text-sm text-slate-600">
                              {model.phenotype}
                            </p>
                          </div>
                        )
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "safety" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Shield className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Safety Concerns
                  </h2>
                </div>
                <div className="space-y-6">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Tissue Expression Profile
                    </h3>
                    <div className="space-y-2">
                      {target.safetyConcerns.tissueExpression.map(
                        (tissue, index) => (
                          <div
                            key={index}
                            className="flex justify-between items-center bg-white p-3 rounded border"
                          >
                            <div>
                              <span className="font-medium text-sm">
                                {tissue.tissue}
                              </span>
                              <span className="ml-2 text-sm text-slate-600">
                                ({tissue.level} expression)
                              </span>
                            </div>
                            <span
                              className={`px-2 py-1 text-xs rounded ${
                                tissue.risk === "Low" ||
                                tissue.risk === "Minimal"
                                  ? "bg-green-100 text-green-700"
                                  : tissue.risk === "Moderate"
                                  ? "bg-yellow-100 text-yellow-700"
                                  : "bg-red-100 text-red-700"
                              }`}
                            >
                              {tissue.risk} Risk
                            </span>
                          </div>
                        )
                      )}
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Toxicity Signals
                    </h3>
                    <div className="space-y-2">
                      {target.safetyConcerns.toxicitySignals.map(
                        (signal, index) => (
                          <div
                            key={index}
                            className="bg-white p-3 rounded border"
                          >
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-medium text-sm">
                                {signal.signal}
                              </span>
                              <span
                                className={`px-2 py-1 text-xs rounded ${
                                  signal.severity === "Low"
                                    ? "bg-green-100 text-green-700"
                                    : signal.severity === "Moderate"
                                    ? "bg-yellow-100 text-yellow-700"
                                    : "bg-red-100 text-red-700"
                                }`}
                              >
                                {signal.severity}
                              </span>
                            </div>
                            <p className="text-sm text-slate-600">
                              Evidence: {signal.evidence}
                            </p>
                          </div>
                        )
                      )}
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Drug Interactions
                    </h3>
                    <div className="space-y-2">
                      {target.safetyConcerns.drugInteractions.map(
                        (interaction, index) => (
                          <div
                            key={index}
                            className="bg-white p-3 rounded border"
                          >
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-medium text-sm">
                                {interaction.drug}
                              </span>
                              <span
                                className={`px-2 py-1 text-xs rounded ${
                                  interaction.severity === "Low"
                                    ? "bg-green-100 text-green-700"
                                    : interaction.severity === "Moderate"
                                    ? "bg-yellow-100 text-yellow-700"
                                    : "bg-red-100 text-red-700"
                                }`}
                              >
                                {interaction.severity}
                              </span>
                            </div>
                            <p className="text-sm text-slate-600">
                              {interaction.interaction}
                            </p>
                          </div>
                        )
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "tractability" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Activity className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Tractability Assessment
                  </h2>
                </div>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-slate-50 rounded-lg p-4">
                      <h3 className="font-medium text-slate-900 mb-3">
                        Drug Class Suitability
                      </h3>
                      <div className="bg-white p-3 rounded border">
                        <div className="text-lg font-semibold text-blue-600 mb-2">
                          {target.tractabilityData.drugClass}
                        </div>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-slate-600">
                              Binding Sites:
                            </span>
                            <span className="font-mono">
                              {target.tractabilityData.knownBindingSites}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-600">
                              Structural Info:
                            </span>
                            <span>
                              {target.tractabilityData.structuralInfo}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-50 rounded-lg p-4">
                      <h3 className="font-medium text-slate-900 mb-3">
                        Modality Readiness
                      </h3>
                      <div className="space-y-3">
                        <div className="bg-white p-3 rounded border">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm font-medium">
                              Small Molecule
                            </span>
                            <span className="text-sm font-mono">
                              {(
                                target.tractabilityData.smallMoleculeReadiness *
                                100
                              ).toFixed(0)}
                              %
                            </span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2">
                            <div
                              className="bg-green-600 h-2 rounded-full transition-all duration-300"
                              style={{
                                width: `${
                                  target.tractabilityData
                                    .smallMoleculeReadiness * 100
                                }%`,
                              }}
                            />
                          </div>
                        </div>
                        <div className="bg-white p-3 rounded border">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm font-medium">
                              Antibody
                            </span>
                            <span className="text-sm font-mono">
                              {(
                                target.tractabilityData.antibodyReadiness * 100
                              ).toFixed(0)}
                              %
                            </span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2">
                            <div
                              className="bg-orange-600 h-2 rounded-full transition-all duration-300"
                              style={{
                                width: `${
                                  target.tractabilityData.antibodyReadiness *
                                  100
                                }%`,
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "explainability" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Brain className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    AI Explainability
                  </h2>
                </div>
                <div className="space-y-6">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Top Contributing Features
                    </h3>
                    <div className="space-y-3">
                      {target.explainabilityData.topFeatures.map(
                        (feature, index) => (
                          <div
                            key={index}
                            className="bg-white p-3 rounded border"
                          >
                            <div className="flex justify-between items-center mb-2">
                              <span className="font-medium text-sm">
                                {feature.feature}
                              </span>
                              <div className="flex items-center space-x-2">
                                <span
                                  className={`text-xs px-2 py-1 rounded ${
                                    feature.direction === "Positive"
                                      ? "bg-green-100 text-green-700"
                                      : "bg-red-100 text-red-700"
                                  }`}
                                >
                                  {feature.direction}
                                </span>
                                <span className="text-sm font-mono">
                                  {(feature.importance * 100).toFixed(1)}%
                                </span>
                              </div>
                            </div>
                            <div className="w-full bg-slate-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full transition-all duration-300 ${
                                  feature.direction === "Positive"
                                    ? "bg-green-600"
                                    : "bg-red-600"
                                }`}
                                style={{
                                  width: `${feature.importance * 100}%`,
                                }}
                              />
                            </div>
                          </div>
                        )
                      )}
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      SHAP Analysis by Category
                    </h3>
                    <div className="space-y-3">
                      {target.explainabilityData.shap.map((category, index) => (
                        <div
                          key={index}
                          className="bg-white p-3 rounded border"
                        >
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-medium text-sm">
                              {category.category}
                            </span>
                            <div className="flex items-center space-x-2">
                              <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                                {(category.confidence * 100).toFixed(0)}%
                                confidence
                              </span>
                              <span className="text-sm font-mono">
                                {category.score.toFixed(2)}
                              </span>
                            </div>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                              style={{
                                width: `${(category.score / 0.5) * 100}%`,
                              }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Info className="w-4 h-4 text-blue-600" />
                      <h3 className="font-medium text-blue-900">
                        Model Information
                      </h3>
                    </div>
                    <p className="text-blue-800 text-sm">
                      Analysis generated using{" "}
                      {target.explainabilityData.modelVersion} with SHAP
                      (SHapley Additive exPlanations) values to explain
                      individual predictions and feature importance.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default TargetDossierDetail;
