import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Shield,
  AlertCircle,
  CheckCircle,
  Eye,
  Plus,
  Bookmark,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import { Target } from "../types/target";

interface RankedTargetsTableProps {
  targets: Target[];
}

const RankedTargetsTable: React.FC<RankedTargetsTableProps> = ({ targets }) => {
  const [sortField, setSortField] = useState<keyof Target>("final_score");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [selectedTargets, setSelectedTargets] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(25);

  const handleSort = (field: keyof Target) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  const sortedTargets = [...targets].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];

    if (typeof aVal === "number" && typeof bVal === "number") {
      return sortDirection === "asc" ? aVal - bVal : bVal - aVal;
    }

    const aStr = String(aVal).toLowerCase();
    const bStr = String(bVal).toLowerCase();
    return sortDirection === "asc"
      ? aStr.localeCompare(bStr)
      : bStr.localeCompare(aStr);
  });

  const paginatedTargets = sortedTargets.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const totalPages = Math.ceil(targets.length / pageSize);

  const getConfidenceBadge = (flags: string[]) => {
    if (flags.includes("HIGH_CONFIDENCE")) {
      return (
        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
          <CheckCircle className="w-3 h-3 mr-1" />
          High
        </span>
      );
    } else if (flags.includes("MODERATE_CONFIDENCE")) {
      return (
        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">
          <AlertCircle className="w-3 h-3 mr-1" />
          Moderate
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full">
        <Shield className="w-3 h-3 mr-1" />
        Unknown
      </span>
    );
  };

  const getScoreColor = (score: number) => {
    if (score >= 0.9) return "text-green-600 bg-green-50";
    if (score >= 0.8) return "text-blue-600 bg-blue-50";
    if (score >= 0.7) return "text-yellow-600 bg-yellow-50";
    return "text-gray-600 bg-gray-50";
  };

  const getTractabilityBadge = (flags: string[]) => {
    if (flags.includes("DRUGGABLE")) {
      return (
        <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">
          Druggable
        </span>
      );
    } else if (flags.includes("CHALLENGING_DRUGGABILITY")) {
      return (
        <span className="px-2 py-1 text-xs bg-orange-100 text-orange-700 rounded">
          Challenging
        </span>
      );
    } else if (flags.includes("UNDRUGGABLE")) {
      return (
        <span className="px-2 py-1 text-xs bg-red-100 text-red-700 rounded">
          Undruggable
        </span>
      );
    }
    return (
      <span className="px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded">
        Unknown
      </span>
    );
  };

  const getSafetyLevel = (flags: string[]) => {
    if (flags.includes("SAFETY_CONCERN")) {
      return (
        <span className="px-2 py-1 text-xs bg-red-100 text-red-700 rounded">
          Concern
        </span>
      );
    }
    return (
      <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">
        Safe
      </span>
    );
  };

  const toggleTargetSelection = (gene: string) => {
    setSelectedTargets((prev) =>
      prev.includes(gene) ? prev.filter((g) => g !== gene) : [...prev, gene]
    );
  };

  const SortButton: React.FC<{
    field: keyof Target;
    children: React.ReactNode;
  }> = ({ field, children }) => (
    <button
      onClick={() => handleSort(field)}
      className="flex items-center space-x-1 text-left hover:text-slate-900 transition-colors"
    >
      <span>{children}</span>
      {sortField === field &&
        (sortDirection === "asc" ? (
          <ChevronUp className="w-4 h-4" />
        ) : (
          <ChevronDown className="w-4 h-4" />
        ))}
    </button>
  );

  if (targets.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 text-center">
        <div className="text-slate-400 mb-2">
          <Shield className="h-12 w-12 mx-auto" />
        </div>
        <h3 className="text-lg font-medium text-slate-900">No targets found</h3>
        <p className="text-slate-600 mt-1">
          Try adjusting your filter criteria
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-slate-900">
              AI-Ranked Targets ({targets.length})
            </h3>
            <p className="text-sm text-slate-600 mt-1">
              Sorted by final confidence score combining ML predictions and
              biological evidence
            </p>
          </div>

          {selectedTargets.length > 0 && (
            <div className="flex items-center space-x-2">
              <span className="text-sm text-slate-600">
                {selectedTargets.length} selected
              </span>
              <button className="px-3 py-1 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                Add to Pipeline
              </button>
              <button className="px-3 py-1 text-sm bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition-colors">
                Export Selected
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  className="rounded border-slate-300"
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedTargets(targets.map((t) => t.gene));
                    } else {
                      setSelectedTargets([]);
                    }
                  }}
                />
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                <SortButton field="gene">Gene</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                <SortButton field="final_score">Final Score</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                <SortButton field="ml_score">ML Score</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                <SortButton field="tps">TPS</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Causality
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Tractability
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Safety
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Key Features
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Summary
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {paginatedTargets.map((target, index) => (
              <motion.tr
                key={target.gene}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.02 }}
                className="hover:bg-slate-50 transition-colors duration-150"
              >
                <td className="px-6 py-4">
                  <input
                    type="checkbox"
                    checked={selectedTargets.includes(target.gene)}
                    onChange={() => toggleTargetSelection(target.gene)}
                    className="rounded border-slate-300"
                  />
                </td>
                <td className="px-6 py-4">
                  <div>
                    <div className="font-mono font-semibold text-slate-900 text-lg">
                      {target.gene}
                    </div>
                    <div className="text-sm text-slate-600">
                      Rank #{(currentPage - 1) * pageSize + index + 1}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-2">
                    <div
                      className={`inline-flex items-center px-3 py-1 rounded-full font-medium ${getScoreColor(
                        target.final_score
                      )}`}
                    >
                      {target.final_score.toFixed(3)}
                    </div>
                    <div className="w-20 bg-slate-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${target.final_score * 100}%` }}
                      />
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="font-mono text-slate-700">
                    {target.ml_score.toFixed(2)}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className="font-mono text-slate-700">
                    {target.tps.toFixed(2)}
                  </span>
                </td>
                <td className="px-6 py-4">
                  {getConfidenceBadge(target.flags)}
                </td>
                <td className="px-6 py-4">
                  {getTractabilityBadge(target.flags)}
                </td>
                <td className="px-6 py-4">{getSafetyLevel(target.flags)}</td>
                <td className="px-6 py-4">
                  <div className="flex flex-wrap gap-1 max-w-xs">
                    {target.top_features.slice(0, 3).map((feature) => (
                      <span
                        key={feature}
                        className="px-2 py-1 text-xs bg-blue-50 text-blue-700 rounded border border-blue-200"
                      >
                        {feature.replace(/_/g, " ")}
                      </span>
                    ))}
                    {target.top_features.length > 3 && (
                      <span className="px-2 py-1 text-xs bg-slate-100 text-slate-600 rounded">
                        +{target.top_features.length - 3}
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 max-w-xs">
                  <p className="text-sm text-slate-600 line-clamp-2">
                    {target.summary}
                  </p>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-2">
                    <Link
                      to={`/targets/${target.gene}`}
                      className="inline-flex items-center px-2 py-1 text-xs font-medium 
                               text-blue-600 bg-blue-50 rounded-md hover:bg-blue-100 
                               transition-colors duration-200"
                    >
                      <Eye className="w-3 h-3 mr-1" />
                      Dossier
                    </Link>
                    <button
                      className="inline-flex items-center px-2 py-1 text-xs font-medium 
                                     text-slate-600 bg-slate-50 rounded-md hover:bg-slate-100 
                                     transition-colors duration-200"
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Pipeline
                    </button>
                    <button
                      className="inline-flex items-center px-2 py-1 text-xs font-medium 
                                     text-slate-600 bg-slate-50 rounded-md hover:bg-slate-100 
                                     transition-colors duration-200"
                    >
                      <Bookmark className="w-3 h-3" />
                    </button>
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50">
          <div className="flex items-center justify-between">
            <div className="text-sm text-slate-600">
              Showing {(currentPage - 1) * pageSize + 1} to{" "}
              {Math.min(currentPage * pageSize, targets.length)} of{" "}
              {targets.length} targets
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1 text-sm border border-slate-300 rounded-md hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              <span className="text-sm text-slate-600">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() =>
                  setCurrentPage(Math.min(totalPages, currentPage + 1))
                }
                disabled={currentPage === totalPages}
                className="px-3 py-1 text-sm border border-slate-300 rounded-md hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RankedTargetsTable;
