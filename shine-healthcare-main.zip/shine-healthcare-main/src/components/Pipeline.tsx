import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Target,
  Search,
  Beaker,
  TestTube,
  Users,
  FileText,
  Play,
  Download,
  BarChart3,
  AlertTriangle,
  CheckCircle,
  Clock,
  Database,
  Brain,
  RefreshCw,
  ChevronRight,
} from "lucide-react";

interface PipelineStep {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  status: "pending" | "running" | "completed" | "error";
  confidence?: number;
  results?: any;
  duration?: string;
}

interface Compound {
  id: string;
  name: string;
  smiles: string;
  score: number;
  properties: {
    potency: number;
    selectivity: number;
    admet: number;
    toxicity: number;
  };
}

const DrugDiscoveryPipelineAgent: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isRunning, setIsRunning] = useState(false);

  const pipelineSteps: PipelineStep[] = [
    {
      id: "target-identification",
      name: "Target Identification & Validation",
      description:
        "Find disease-related targets using omics data, literature, and pathway analysis",
      icon: Target,
      status: "completed",
      confidence: 0.92,
      duration: "2h 15m",
    },
    {
      id: "hit-discovery",
      name: "Hit Discovery",
      description:
        "Virtual screening on compound libraries with AI/ML binding affinity prediction",
      icon: Search,
      status: "completed",
      confidence: 0.88,
      duration: "4h 32m",
    },
    {
      id: "lead-optimization",
      name: "Lead Optimization",
      description:
        "Chemical modifications using generative models to improve potency and safety",
      icon: Beaker,
      status: "running",
      confidence: 0.76,
      duration: "Running...",
    },
    {
      id: "preclinical-testing",
      name: "Preclinical Testing (In-silico)",
      description:
        "Predict toxicity, metabolism, and bioavailability for optimized leads",
      icon: TestTube,
      status: "pending",
      duration: "Pending",
    },
    {
      id: "clinical-preview",
      name: "Clinical Trial Preview",
      description:
        "Trial strategy, patient population estimation, and endpoint selection",
      icon: Users,
      status: "pending",
      duration: "Pending",
    },
    {
      id: "regulatory",
      name: "Regulatory & Post-Market",
      description:
        "Compile dossier for regulatory review with reproducibility metadata",
      icon: FileText,
      status: "pending",
      duration: "Pending",
    },
  ];

  const mockCompounds: Compound[] = [
    {
      id: "CPD-001",
      name: "ChemGen-α-7842",
      smiles: "CC(C)CC1=CC=C(C=C1)C(C)C(=O)NC2=CC=CC=C2",
      score: 0.94,
      properties: {
        potency: 0.92,
        selectivity: 0.89,
        admet: 0.85,
        toxicity: 0.91,
      },
    },
    {
      id: "CPD-002",
      name: "OptLead-β-3901",
      smiles: "COC1=CC=C(C=C1)C2=NC(=CS2)C3=CC=CC=C3",
      score: 0.89,
      properties: {
        potency: 0.88,
        selectivity: 0.84,
        admet: 0.92,
        toxicity: 0.87,
      },
    },
    {
      id: "CPD-003",
      name: "VirScreen-γ-1256",
      smiles: "C1=CC=C(C=C1)C2=CC=C(C=C2)C3=NOC(=C3)C",
      score: 0.83,
      properties: {
        potency: 0.85,
        selectivity: 0.79,
        admet: 0.88,
        toxicity: 0.89,
      },
    },
  ];

  const runPipelineStep = async (stepIndex: number) => {
    setIsRunning(true);
    setCurrentStep(stepIndex);

    // Simulate AI processing
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Update step status
    const updatedSteps = [...pipelineSteps];
    updatedSteps[stepIndex].status = "completed";

    setIsRunning(false);
  };

  const exportResults = (format: "json" | "csv" | "pdf") => {
    const data = {
      pipeline: pipelineSteps,
      compounds: mockCompounds,
      metadata: {
        modelVersion: "v2.1.3",
        datasetId: "ChEMBL-2024-Q3",
        timestamp: new Date().toISOString(),
        confidence: 0.87,
      },
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pipeline-results.${format}`;
    a.click();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-600 bg-green-50 border-green-200";
      case "running":
        return "text-blue-600 bg-blue-50 border-blue-200";
      case "error":
        return "text-red-600 bg-red-50 border-red-200";
      default:
        return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return CheckCircle;
      case "running":
        return RefreshCw;
      case "error":
        return AlertTriangle;
      default:
        return Clock;
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              Drug Discovery Pipeline Agent
            </h1>
            <p className="text-blue-100 text-lg">
              AI Research Assistant for End-to-End Drug Discovery
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Brain className="w-12 h-12 text-blue-200" />
            <div className="text-right">
              <div className="text-2xl font-bold">87%</div>
              <div className="text-sm text-blue-200">Overall Confidence</div>
            </div>
          </div>
        </div>
      </div>

      {/* Pipeline Overview */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-slate-900">
            Pipeline Progress
          </h2>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => runPipelineStep(currentStep)}
              disabled={isRunning}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {isRunning ? (
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Play className="w-4 h-4 mr-2" />
              )}
              {isRunning ? "Running..." : "Run Next Step"}
            </button>
            <button
              onClick={() => exportResults("json")}
              className="flex items-center px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200"
            >
              <Download className="w-4 h-4 mr-2" />
              Export
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {pipelineSteps.map((step, index) => {
            const StatusIcon = getStatusIcon(step.status);
            return (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-4 rounded-lg border ${getStatusColor(
                  step.status
                )} cursor-pointer hover:shadow-md transition-all`}
                onClick={() => setCurrentStep(index)}
              >
                <div className="flex items-start justify-between mb-3">
                  <step.icon className="w-6 h-6" />
                  <StatusIcon className="w-5 h-5" />
                </div>
                <h3 className="font-semibold mb-2">{step.name}</h3>
                <p className="text-sm opacity-80 mb-3">{step.description}</p>
                <div className="flex items-center justify-between text-sm">
                  <span>{step.duration}</span>
                  {step.confidence && (
                    <span className="font-mono">
                      {(step.confidence * 100).toFixed(0)}%
                    </span>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Active Step Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Step Details */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center space-x-3 mb-6">
            {React.createElement(pipelineSteps[currentStep].icon, {
              className: "w-6 h-6 text-blue-600",
            })}
            <h3 className="text-xl font-semibold text-slate-900">
              {pipelineSteps[currentStep].name}
            </h3>
          </div>

          {currentStep === 0 && (
            <div className="space-y-6">
              <div className="bg-slate-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold">Target Scorecard</h4>
                  <Link
                    to="/targets/top"
                    className="flex items-center px-3 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                  >
                    <Target className="w-4 h-4 mr-2" />
                    View All Targets
                  </Link>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-3 rounded border">
                    <div className="text-2xl font-bold text-green-600">
                      CYP2C19
                    </div>
                    <div className="text-sm text-slate-600">Top Target</div>
                    <div className="mt-2 space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Disease Relevance:</span>
                        <span className="font-mono">0.94</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Druggability:</span>
                        <span className="font-mono">0.89</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Novelty:</span>
                        <span className="font-mono">0.76</span>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white p-3 rounded border">
                    <div className="text-2xl font-bold text-blue-600">
                      ABCB1
                    </div>
                    <div className="text-sm text-slate-600">
                      Alternative Target
                    </div>
                    <div className="mt-2 space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Disease Relevance:</span>
                        <span className="font-mono">0.87</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Druggability:</span>
                        <span className="font-mono">0.82</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span>Novelty:</span>
                        <span className="font-mono">0.91</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded">
                  <p className="text-sm text-blue-800">
                    🎯 <strong>AI Summary:</strong> Identified 47
                    high-confidence targets from multi-omics analysis. Top
                    candidates show strong genetic evidence and druggability
                    potential.
                  </p>
                </div>
              </div>
            </div>
          )}

          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="bg-slate-50 rounded-lg p-4">
                <h4 className="font-semibold mb-3">
                  Virtual Screening Results
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2">Compound</th>
                        <th className="text-left py-2">Score</th>
                        <th className="text-left py-2">Potency</th>
                        <th className="text-left py-2">ADMET</th>
                        <th className="text-left py-2">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockCompounds.map((compound) => (
                        <tr key={compound.id} className="border-b">
                          <td className="py-2">
                            <div>
                              <div className="font-mono font-semibold">
                                {compound.id}
                              </div>
                              <div className="text-xs text-slate-600">
                                {compound.name}
                              </div>
                            </div>
                          </td>
                          <td className="py-2">
                            <span className="font-mono text-green-600">
                              {compound.score.toFixed(2)}
                            </span>
                          </td>
                          <td className="py-2">
                            <span className="font-mono">
                              {compound.properties.potency.toFixed(2)}
                            </span>
                          </td>
                          <td className="py-2">
                            <span className="font-mono">
                              {compound.properties.admet.toFixed(2)}
                            </span>
                          </td>
                          <td className="py-2">
                            <button className="text-blue-600 hover:text-blue-800">
                              <ChevronRight className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="bg-slate-50 rounded-lg p-4">
                <h4 className="font-semibold mb-3">
                  Lead Optimization Progress
                </h4>
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded border">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">
                        Generative Model Processing
                      </span>
                      <span className="text-blue-600">Running...</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: "68%" }}
                      ></div>
                    </div>
                    <div className="text-xs text-slate-600 mt-1">
                      Generating 1,247 molecular variants
                    </div>
                  </div>
                  <div className="bg-white p-4 rounded border">
                    <div className="text-sm">
                      <strong>Current Best Lead:</strong> OptLead-β-3901
                    </div>
                    <div className="text-xs text-slate-600 mt-1">
                      Improved potency by 23%, maintained selectivity
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Metadata & Controls */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="font-semibold text-slate-900 mb-4">
              Pipeline Metadata
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-600">Model Version:</span>
                <span className="font-mono">v2.1.3</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Dataset ID:</span>
                <span className="font-mono">ChEMBL-2024-Q3</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Started:</span>
                <span>2 hours ago</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Compounds Screened:</span>
                <span className="font-mono">2.4M</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Hit Rate:</span>
                <span className="font-mono">0.012%</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="font-semibold text-slate-900 mb-4">
              Export Options
            </h3>
            <div className="space-y-2">
              <button
                onClick={() => exportResults("json")}
                className="w-full flex items-center justify-center px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200"
              >
                <Database className="w-4 h-4 mr-2" />
                JSON Data
              </button>
              <button
                onClick={() => exportResults("csv")}
                className="w-full flex items-center justify-center px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                CSV Report
              </button>
              <button
                onClick={() => exportResults("pdf")}
                className="w-full flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                <FileText className="w-4 h-4 mr-2" />
                PDF Dossier
              </button>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-start space-x-2">
              <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-yellow-800">
                  Human Review Required
                </h4>
                <p className="text-xs text-yellow-700 mt-1">
                  Lead optimization results need expert validation before
                  proceeding to preclinical testing.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DrugDiscoveryPipelineAgent;
