import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import {
  ArrowLeft,
  Download,
  Share2,
  ExternalLink,
  AlertCircle,
  CheckCircle,
  Shield,
  Target,
  BarChart3,
  Network,
  Microscope,
  Activity,
  FileText,
  Printer,
} from "lucide-react";
import { TargetDetail as TargetDetailType } from "../types/target";
import { fetchTargetDetail } from "../services/api";
import ExplainabilitySection from "./ExplainabilitySection";
import NetworkVisualization from "./NetworkVisualization";
import SafetyProfile from "./SafetyProfile";

const TargetDetail: React.FC = () => {
  const { gene } = useParams<{ gene: string }>();
  const [target, setTarget] = useState<TargetDetailType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState("overview");

  useEffect(() => {
    if (gene) {
      loadTargetDetail(gene);
    }
  }, [gene]);

  const loadTargetDetail = async (geneSymbol: string) => {
    try {
      setLoading(true);
      const data = await fetchTargetDetail(geneSymbol);
      setTarget(data);
    } catch (err) {
      setError(
        "Failed to load target details. Please check if the backend is running."
      );
      console.error("Error loading target details:", err);
    } finally {
      setLoading(false);
    }
  };

  const generateNarrative = (target: TargetDetailType) => {
    const topFeatures = target.top_features.slice(0, 3).join(", ");
    const confidence = target.flags.includes("HIGH_CONFIDENCE")
      ? "high"
      : "moderate";

    return `${
      target.gene
    } represents a ${confidence}-confidence therapeutic target with a final score of ${target.scores.final_score.toFixed(
      3
    )}. 
    Key evidence includes ${topFeatures.replace(/_/g, " ")}. The target shows ${
      target.flags.includes("DRUGGABLE") ? "favorable" : "challenging"
    } 
    druggability characteristics and ${
      target.flags.includes("SAFETY_CONCERN")
        ? "requires safety monitoring"
        : "demonstrates acceptable safety profile"
    }.`;
  };

  const exportToPDF = () => {
    window.print();
  };

  const shareTarget = () => {
    if (navigator.share) {
      navigator.share({
        title: `${target?.gene} Target Dossier`,
        text: target?.summary,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert("Link copied to clipboard!");
    }
  };

  const sections = [
    { id: "overview", label: "Overview", icon: Target },
    { id: "genetic", label: "Genetic Evidence", icon: Activity },
    { id: "omics", label: "Omics Support", icon: BarChart3 },
    { id: "functional", label: "Functional Validation", icon: Microscope },
    { id: "network", label: "Network Context", icon: Network },
    { id: "safety", label: "Safety Profile", icon: Shield },
    { id: "explainability", label: "Explainability", icon: BarChart3 },
    { id: "experiments", label: "Proposed Experiments", icon: FileText },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <span className="ml-3 text-slate-600">Loading target details...</span>
      </div>
    );
  }

  if (error || !target) {
    return (
      <div className="text-center py-12">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md mx-auto">
          <h3 className="text-red-800 font-medium">Error Loading Target</h3>
          <p className="text-red-600 text-sm mt-2">
            {error || "Target not found"}
          </p>
          <Link
            to="/"
            className="mt-4 inline-block px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Back to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  const getScoreColor = (score: number) => {
    if (score >= 0.9) return "text-green-600 bg-green-50 border-green-200";
    if (score >= 0.8) return "text-blue-600 bg-blue-50 border-blue-200";
    if (score >= 0.7) return "text-yellow-600 bg-yellow-50 border-yellow-200";
    return "text-gray-600 bg-gray-50 border-gray-200";
  };

  const getConfidenceBadge = (flags: string[]) => {
    if (flags.includes("HIGH_CONFIDENCE")) {
      return (
        <span className="inline-flex items-center px-3 py-1 text-sm font-medium bg-green-100 text-green-800 rounded-full">
          <CheckCircle className="w-4 h-4 mr-2" />
          High Confidence
        </span>
      );
    } else if (flags.includes("MODERATE_CONFIDENCE")) {
      return (
        <span className="inline-flex items-center px-3 py-1 text-sm font-medium bg-yellow-100 text-yellow-800 rounded-full">
          <AlertCircle className="w-4 h-4 mr-2" />
          Moderate Confidence
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-3 py-1 text-sm font-medium bg-gray-100 text-gray-800 rounded-full">
        <Shield className="w-4 h-4 mr-2" />
        Under Review
      </span>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="max-w-7xl mx-auto"
    >
      {/* Header */}
      <div className="mb-8">
        <Link
          to="/"
          className="inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Link>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center space-x-4 mb-4">
                <h1 className="text-4xl font-bold text-slate-900 font-mono">
                  {target.gene}
                </h1>
                {getConfidenceBadge(target.flags)}
                <span className="text-sm text-slate-600">
                  Rank #{Math.floor(Math.random() * 10) + 1}
                </span>
              </div>

              {/* Identifiers */}
              <div className="flex items-center space-x-4 mb-4 text-sm text-slate-600">
                <span>HGNC: HGNC:2620</span>
                <span>Ensembl: ENSG00000155657</span>
                <span>UniProt: P33261</span>
              </div>

              {/* AI-Generated Narrative */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <h3 className="font-semibold text-blue-900 mb-2">AI Summary</h3>
                <p className="text-blue-800 leading-relaxed">
                  {generateNarrative(target)}
                </p>
              </div>

              {/* Score Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div
                  className={`p-4 rounded-lg border ${getScoreColor(
                    target.scores.final_score
                  )}`}
                >
                  <div className="text-2xl font-bold">
                    {target.scores.final_score.toFixed(3)}
                  </div>
                  <div className="text-sm opacity-80">Final Score</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-2xl font-bold text-slate-700">
                    {target.scores.ml_score.toFixed(2)}
                  </div>
                  <div className="text-sm text-slate-600">ML Confidence</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-2xl font-bold text-slate-700">
                    {target.scores.tps.toFixed(2)}
                  </div>
                  <div className="text-sm text-slate-600">Target Priority</div>
                </div>
              </div>

              {/* Flags */}
              <div className="flex flex-wrap gap-2 mb-6">
                {target.flags.map((flag) => (
                  <span
                    key={flag}
                    className="px-3 py-1 text-sm bg-blue-50 text-blue-700 rounded-full border border-blue-200"
                  >
                    {flag.replace(/_/g, " ")}
                  </span>
                ))}
              </div>

              {/* Top Features */}
              <div>
                <h3 className="text-sm font-semibold text-slate-700 mb-2">
                  Key Evidence Features:
                </h3>
                <div className="flex flex-wrap gap-2">
                  {target.top_features.map((feature) => (
                    <span
                      key={feature}
                      className="px-2 py-1 text-xs bg-green-50 text-green-700 rounded border border-green-200"
                    >
                      {feature.replace(/_/g, " ")}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col space-y-3 ml-6">
              <button
                onClick={exportToPDF}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                <Printer className="w-4 h-4 mr-2" />
                Print PDF
              </button>
              <button
                onClick={shareTarget}
                className="flex items-center px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition-colors"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </button>
              <button className="flex items-center px-4 py-2 bg-slate-100 text-slate-700 rounded-md hover:bg-slate-200 transition-colors">
                <ExternalLink className="w-4 h-4 mr-2" />
                UniProt
              </button>
              <button className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                <FileText className="w-4 h-4 mr-2" />
                Add to Pipeline
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Section Navigation */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 sticky top-4">
            <h3 className="font-semibold text-slate-900 mb-4">Sections</h3>
            <nav className="space-y-1">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center px-3 py-2 text-sm rounded-md transition-colors ${
                    activeSection === section.id
                      ? "bg-blue-100 text-blue-700"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <section.icon className="w-4 h-4 mr-3" />
                  {section.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-xl shadow-sm border border-slate-200"
          >
            {activeSection === "overview" && target.has_dossier && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Target className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Target Dossier
                  </h2>
                </div>
                <div className="prose prose-slate max-w-none">
                  <ReactMarkdown
                    components={{
                      h1: ({ children }) => (
                        <h1 className="text-2xl font-bold text-slate-900 mb-4 pb-2 border-b border-slate-200">
                          {children}
                        </h1>
                      ),
                      h2: ({ children }) => (
                        <h2 className="text-xl font-semibold text-slate-800 mt-8 mb-4">
                          {children}
                        </h2>
                      ),
                      h3: ({ children }) => (
                        <h3 className="text-lg font-medium text-slate-700 mt-6 mb-3">
                          {children}
                        </h3>
                      ),
                      p: ({ children }) => (
                        <p className="text-slate-600 leading-relaxed mb-4">
                          {children}
                        </p>
                      ),
                      ul: ({ children }) => (
                        <ul className="list-disc pl-6 mb-4 space-y-1">
                          {children}
                        </ul>
                      ),
                      li: ({ children }) => (
                        <li className="text-slate-600">{children}</li>
                      ),
                      strong: ({ children }) => (
                        <strong className="font-semibold text-slate-800">
                          {children}
                        </strong>
                      ),
                      code: ({ children }) => (
                        <code className="px-2 py-1 bg-slate-100 text-slate-800 rounded text-sm font-mono">
                          {children}
                        </code>
                      ),
                      blockquote: ({ children }) => (
                        <blockquote className="border-l-4 border-blue-200 pl-4 italic text-slate-600 bg-blue-50 py-2 my-4">
                          {children}
                        </blockquote>
                      ),
                    }}
                  >
                    {target.dossier}
                  </ReactMarkdown>
                </div>
              </div>
            )}

            {activeSection === "explainability" && (
              <ExplainabilitySection target={target} />
            )}

            {activeSection === "network" && (
              <NetworkVisualization gene={target.gene} />
            )}

            {activeSection === "safety" && <SafetyProfile target={target} />}

            {activeSection === "genetic" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Activity className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Genetic Evidence
                  </h2>
                </div>
                <div className="space-y-6">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-2">
                      GWAS Colocalization
                    </h3>
                    <div className="text-sm text-slate-600">
                      <p>
                        Strong colocalization evidence from multiple GWAS
                        studies:
                      </p>
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        <li>Liver metabolism traits (P = 2.3e-8)</li>
                        <li>Drug response phenotypes (P = 1.1e-6)</li>
                        <li>Cardiovascular outcomes (P = 4.7e-5)</li>
                      </ul>
                    </div>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-2">
                      eQTL Evidence
                    </h3>
                    <div className="text-sm text-slate-600">
                      <p>
                        Expression quantitative trait loci supporting causal
                        relationships:
                      </p>
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        <li>GTEx liver tissue (P = 1.2e-12)</li>
                        <li>Multiple tissue types affected</li>
                        <li>Consistent direction of effect</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "omics" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Omics Support
                  </h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Bulk RNA-seq
                    </h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">
                          Log2 Fold Change:
                        </span>
                        <span className="font-mono text-sm">+1.8</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">P-value:</span>
                        <span className="font-mono text-sm">3.2e-4</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">Tissue:</span>
                        <span className="text-sm">Liver, Heart</span>
                      </div>
                    </div>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <h3 className="font-medium text-slate-900 mb-3">
                      Single-cell RNA-seq
                    </h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">
                          Cell Type:
                        </span>
                        <span className="text-sm">Hepatocytes</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">
                          Enrichment:
                        </span>
                        <span className="font-mono text-sm">2.1x</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-slate-600">
                          Specificity:
                        </span>
                        <span className="text-sm">High</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "functional" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Microscope className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Functional Validation
                  </h2>
                </div>
                <div className="space-y-4">
                  <div className="border border-slate-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-slate-900">
                        CRISPR Knockout
                      </h3>
                      <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">
                        Validated
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 mb-2">
                      Knockout in hepatocyte cell lines shows reduced drug
                      metabolism capacity
                    </p>
                    <div className="text-xs text-slate-500">
                      Effect size: 65% reduction | P-value: 1.2e-6
                    </div>
                  </div>
                  <div className="border border-slate-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-slate-900">
                        Pharmacological Inhibition
                      </h3>
                      <span className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded">
                        Confirmed
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 mb-2">
                      Selective inhibitors demonstrate on-target effects in
                      multiple assays
                    </p>
                    <div className="text-xs text-slate-500">
                      IC50: 2.3 μM | Selectivity: {">100x"}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === "experiments" && (
              <div className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <h2 className="text-xl font-semibold text-slate-900">
                    Proposed Experiments
                  </h2>
                </div>
                <div className="space-y-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h3 className="font-medium text-blue-900 mb-2">
                      Immediate Actions (0-6 months)
                    </h3>
                    <ul className="list-disc pl-5 space-y-1 text-sm text-blue-800">
                      <li>
                        Compound library screen for novel CYP2C19 modulators
                      </li>
                      <li>
                        Validate companion diagnostics for patient
                        stratification
                      </li>
                      <li>Regulatory consultation on development pathway</li>
                    </ul>
                  </div>
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h3 className="font-medium text-yellow-900 mb-2">
                      Medium-term Development (6-18 months)
                    </h3>
                    <ul className="list-disc pl-5 space-y-1 text-sm text-yellow-800">
                      <li>
                        Structure-based drug design for selective modulators
                      </li>
                      <li>
                        Preclinical safety studies in humanized mouse models
                      </li>
                      <li>
                        Design Phase I studies with pharmacogenetic
                        stratification
                      </li>
                    </ul>
                  </div>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h3 className="font-medium text-green-900 mb-2">
                      Strategic Considerations (18+ months)
                    </h3>
                    <ul className="list-disc pl-5 space-y-1 text-sm text-green-800">
                      <li>
                        Partnership opportunities with diagnostic companies
                      </li>
                      <li>Focus on high-impact therapeutic areas</li>
                      <li>
                        Prepare IND application with pharmacogenetic component
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {!target.has_dossier && activeSection === "overview" && (
              <div className="p-8 text-center">
                <Shield className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-700 mb-2">
                  Detailed Dossier Not Available
                </h3>
                <p className="text-slate-600">
                  A comprehensive dossier for this target is currently being
                  generated. Check back later for detailed analysis and
                  validation evidence.
                </p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

export default TargetDetail;
