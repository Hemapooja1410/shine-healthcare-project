import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronRight, Shield, AlertCircle, CheckCircle } from 'lucide-react';
import { Target } from '../types/target';

interface TargetTableProps {
  targets: Target[];
}

const TargetTable: React.FC<TargetTableProps> = ({ targets }) => {
  const getConfidenceBadge = (flags: string[]) => {
    if (flags.includes('HIGH_CONFIDENCE')) {
      return (
        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
          <CheckCircle className="w-3 h-3 mr-1" />
          High
        </span>
      );
    } else if (flags.includes('MODERATE_CONFIDENCE')) {
      return (
        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">
          <AlertCircle className="w-3 h-3 mr-1" />
          Moderate
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full">
        <Shield className="w-3 h-3 mr-1" />
        Unknown
      </span>
    );
  };

  const getScoreColor = (score: number) => {
    if (score >= 0.9) return 'text-green-600 bg-green-50';
    if (score >= 0.8) return 'text-blue-600 bg-blue-50';
    if (score >= 0.7) return 'text-yellow-600 bg-yellow-50';
    return 'text-gray-600 bg-gray-50';
  };

  const getDruggabilityBadge = (flags: string[]) => {
    if (flags.includes('DRUGGABLE')) {
      return <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">Druggable</span>;
    } else if (flags.includes('CHALLENGING_DRUGGABILITY')) {
      return <span className="px-2 py-1 text-xs bg-orange-100 text-orange-700 rounded">Challenging</span>;
    } else if (flags.includes('UNDRUGGABLE')) {
      return <span className="px-2 py-1 text-xs bg-red-100 text-red-700 rounded">Undruggable</span>;
    }
    return null;
  };

  if (targets.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 text-center">
        <div className="text-slate-400 mb-2">
          <Shield className="h-12 w-12 mx-auto" />
        </div>
        <h3 className="text-lg font-medium text-slate-900">No targets found</h3>
        <p className="text-slate-600 mt-1">Try adjusting your search criteria</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
        <h3 className="text-lg font-semibold text-slate-900">
          AI-Ranked Targets ({targets.length})
        </h3>
        <p className="text-sm text-slate-600 mt-1">
          Sorted by final confidence score combining ML predictions and biological evidence
        </p>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Target
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Final Score
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Confidence
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Summary
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                Action
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {targets.map((target, index) => (
              <motion.tr
                key={target.gene}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="hover:bg-slate-50 transition-colors duration-150"
              >
                <td className="px-6 py-4">
                  <div>
                    <div className="font-mono font-semibold text-slate-900 text-lg">
                      {target.gene}
                    </div>
                    <div className="text-sm text-slate-600">
                      ML: {target.ml_score.toFixed(2)} | TPS: {target.tps.toFixed(2)}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className={`inline-flex items-center px-3 py-1 rounded-full font-medium ${getScoreColor(target.final_score)}`}>
                    {target.final_score.toFixed(3)}
                  </div>
                </td>
                <td className="px-6 py-4">
                  {getConfidenceBadge(target.flags)}
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-wrap gap-1">
                    {getDruggabilityBadge(target.flags)}
                    {target.flags.includes('VALIDATED_TARGET') && (
                      <span className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded">
                        Validated
                      </span>
                    )}
                    {target.flags.includes('SAFETY_CONCERN') && (
                      <span className="px-2 py-1 text-xs bg-red-100 text-red-700 rounded">
                        Safety Risk
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 max-w-xs">
                  <p className="text-sm text-slate-600 line-clamp-2">
                    {target.summary}
                  </p>
                </td>
                <td className="px-6 py-4">
                  <Link
                    to={`/target/${target.gene}`}
                    className="inline-flex items-center px-3 py-2 text-sm font-medium 
                             text-blue-600 bg-blue-50 rounded-md hover:bg-blue-100 
                             transition-colors duration-200"
                  >
                    View Dossier
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TargetTable;