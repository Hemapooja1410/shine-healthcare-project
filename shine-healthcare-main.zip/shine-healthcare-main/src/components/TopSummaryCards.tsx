import React from 'react';
import { motion } from 'framer-motion';
import { Target, TrendingUp, Shield, Award, AlertTriangle } from 'lucide-react';
import { Target as TargetType } from '../types/target';

interface TopSummaryCardsProps {
  targets: TargetType[];
}

const TopSummaryCards: React.FC<TopSummaryCardsProps> = ({ targets }) => {
  const topTarget = targets.length > 0 ? targets[0] : null;
  const top5Avg = targets.length >= 5 
    ? targets.slice(0, 5).reduce((sum, t) => sum + t.final_score, 0) / 5 
    : 0;
  
  const highConfidenceCount = targets.filter(t => 
    t.flags.includes('HIGH_CONFIDENCE')
  ).length;

  const enrichmentMetric = targets.length > 0 
    ? (highConfidenceCount / targets.length) * 100 
    : 0;

  const cards = [
    {
      title: 'Top Target',
      value: topTarget ? topTarget.gene : 'N/A',
      subtitle: topTarget ? `Score: ${topTarget.final_score.toFixed(3)}` : '',
      icon: Award,
      color: 'gold',
      description: 'Highest ranked target'
    },
    {
      title: 'Top 5 Average',
      value: top5Avg.toFixed(3),
      subtitle: 'Mean confidence score',
      icon: TrendingUp,
      color: 'blue',
      description: 'Average of top 5 targets'
    },
    {
      title: 'High Confidence',
      value: highConfidenceCount,
      subtitle: `${enrichmentMetric.toFixed(1)}% of total`,
      icon: Shield,
      color: 'green',
      description: 'Strong evidence validation'
    },
    {
      title: 'Total Targets',
      value: targets.length,
      subtitle: 'AI-scored candidates',
      icon: Target,
      color: 'purple',
      description: 'Complete target set'
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'gold':
        return 'bg-yellow-50 text-yellow-600 border-yellow-200';
      case 'blue':
        return 'bg-blue-50 text-blue-600 border-blue-200';
      case 'green':
        return 'bg-green-50 text-green-600 border-green-200';
      case 'purple':
        return 'bg-purple-50 text-purple-600 border-purple-200';
      default:
        return 'bg-gray-50 text-gray-600 border-gray-200';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 * index }}
          className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 hover:shadow-md transition-shadow duration-200"
        >
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="text-sm font-medium text-slate-600">{card.title}</p>
              <p className="text-2xl font-bold text-slate-900 mt-2 font-mono">
                {card.value}
              </p>
              {card.subtitle && (
                <p className="text-sm text-slate-500 mt-1">{card.subtitle}</p>
              )}
              <p className="text-xs text-slate-400 mt-2">{card.description}</p>
            </div>
            <div className={`p-3 rounded-lg ${getColorClasses(card.color)}`}>
              <card.icon className="h-6 w-6" />
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default TopSummaryCards;