import React from 'react';
import { motion } from 'framer-motion';
import { Target, TrendingUp, Shield, AlertTriangle } from 'lucide-react';
import { Target as TargetType } from '../types/target';

interface StatsCardsProps {
  targets: TargetType[];
}

const StatsCards: React.FC<StatsCardsProps> = ({ targets }) => {
  const highConfidenceCount = targets.filter(t => 
    t.flags.includes('HIGH_CONFIDENCE')
  ).length;

  const druggableCount = targets.filter(t => 
    t.flags.includes('DRUGGABLE')
  ).length;

  const validatedCount = targets.filter(t => 
    t.flags.includes('VALIDATED_TARGET')
  ).length;

  const avgScore = targets.length > 0 
    ? targets.reduce((sum, t) => sum + t.final_score, 0) / targets.length 
    : 0;

  const cards = [
    {
      title: 'Total Targets',
      value: targets.length,
      icon: Target,
      color: 'blue',
      description: 'AI-scored protein targets'
    },
    {
      title: 'High Confidence',
      value: highConfidenceCount,
      icon: Shield,
      color: 'green',
      description: 'Strong evidence validation'
    },
    {
      title: 'Druggable',
      value: druggableCount,
      icon: TrendingUp,
      color: 'purple',
      description: 'Therapeutically tractable'
    },
    {
      title: 'Avg Score',
      value: avgScore.toFixed(2),
      icon: AlertTriangle,
      color: 'orange',
      description: 'Mean confidence score'
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue':
        return 'bg-blue-50 text-blue-600 border-blue-200';
      case 'green':
        return 'bg-green-50 text-green-600 border-green-200';
      case 'purple':
        return 'bg-purple-50 text-purple-600 border-purple-200';
      case 'orange':
        return 'bg-orange-50 text-orange-600 border-orange-200';
      default:
        return 'bg-gray-50 text-gray-600 border-gray-200';
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 * index }}
          className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 hover:shadow-md transition-shadow duration-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">{card.title}</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">{card.value}</p>
              <p className="text-sm text-slate-500 mt-1">{card.description}</p>
            </div>
            <div className={`p-3 rounded-lg ${getColorClasses(card.color)}`}>
              <card.icon className="h-6 w-6" />
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default StatsCards;