import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Search,
  Filter,
  Download,
  Eye,
  ArrowUpDown,
  ChevronDown,
  Target,
  Shield,
  AlertCircle,
  CheckCircle,
  ArrowLeft,
} from "lucide-react";

interface TargetData {
  gene: string;
  finalScore: number;
  causality: "High" | "Moderate" | "Low";
  tractability: "Druggable" | "Challenging" | "Undruggable";
  safety: "Safe" | "Concern" | "Unknown";
  keyFeatures: string[];
  summary: string;
  rank: number;
  confidence: number;
  mlScore: number;
  tps: number;
  diseaseRelevance: number;
  druggability: number;
  novelty: number;
}

const TargetsTop: React.FC = () => {
  const [targets, setTargets] = useState<TargetData[]>([]);
  const [filteredTargets, setFilteredTargets] = useState<TargetData[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortField, setSortField] = useState<keyof TargetData>("finalScore");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [filters, setFilters] = useState({
    scoreThreshold: 0.0,
    tractability: "all",
    safety: "all",
    causality: "all",
  });
  const [showFilters, setShowFilters] = useState(false);

  // Mock data - replace with API call
  const mockTargets: TargetData[] = [
    {
      gene: "CYP2C19",
      finalScore: 0.943,
      causality: "High",
      tractability: "Druggable",
      safety: "Safe",
      keyFeatures: ["Drug Metabolism", "Pharmacogenetics", "Liver Expression"],
      summary:
        "Critical enzyme in drug metabolism with well-established pharmacogenetic markers and therapeutic relevance.",
      rank: 1,
      confidence: 0.92,
      mlScore: 0.89,
      tps: 0.87,
      diseaseRelevance: 0.94,
      druggability: 0.89,
      novelty: 0.76,
    },
    {
      gene: "ABCB1",
      finalScore: 0.887,
      causality: "High",
      tractability: "Challenging",
      safety: "Safe",
      keyFeatures: ["Efflux Pump", "Drug Resistance", "BBB Transport"],
      summary:
        "Multi-drug resistance protein with significant impact on drug disposition and therapeutic efficacy.",
      rank: 2,
      confidence: 0.88,
      mlScore: 0.85,
      tps: 0.82,
      diseaseRelevance: 0.87,
      druggability: 0.82,
      novelty: 0.91,
    },
    {
      gene: "SLCO1B1",
      finalScore: 0.834,
      causality: "Moderate",
      tractability: "Druggable",
      safety: "Safe",
      keyFeatures: ["Hepatic Uptake", "Statin Transport", "Genetic Variants"],
      summary:
        "Hepatic uptake transporter critical for drug disposition with clinical pharmacogenetic applications.",
      rank: 3,
      confidence: 0.83,
      mlScore: 0.81,
      tps: 0.79,
      diseaseRelevance: 0.85,
      druggability: 0.88,
      novelty: 0.72,
    },
    {
      gene: "CYP3A4",
      finalScore: 0.798,
      causality: "High",
      tractability: "Challenging",
      safety: "Concern",
      keyFeatures: ["Major CYP", "Drug Interactions", "Induction"],
      summary:
        "Primary hepatic cytochrome P450 enzyme responsible for metabolism of majority of marketed drugs.",
      rank: 4,
      confidence: 0.79,
      mlScore: 0.77,
      tps: 0.75,
      diseaseRelevance: 0.92,
      druggability: 0.65,
      novelty: 0.58,
    },
    {
      gene: "UGT1A1",
      finalScore: 0.756,
      causality: "Moderate",
      tractability: "Druggable",
      safety: "Safe",
      keyFeatures: [
        "Glucuronidation",
        "Bilirubin Metabolism",
        "Genetic Polymorphisms",
      ],
      summary:
        "UDP-glucuronosyltransferase involved in Phase II metabolism with clinical genetic testing applications.",
      rank: 5,
      confidence: 0.76,
      mlScore: 0.74,
      tps: 0.73,
      diseaseRelevance: 0.78,
      druggability: 0.82,
      novelty: 0.69,
    },
  ];

  useEffect(() => {
    // Simulate API call
    setTargets(mockTargets);
    setFilteredTargets(mockTargets);
  }, []);

  useEffect(() => {
    let filtered = targets.filter((target) => {
      const matchesSearch =
        target.gene.toLowerCase().includes(searchTerm.toLowerCase()) ||
        target.summary.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesScore = target.finalScore >= filters.scoreThreshold;
      const matchesTractability =
        filters.tractability === "all" ||
        target.tractability === filters.tractability;
      const matchesSafety =
        filters.safety === "all" || target.safety === filters.safety;
      const matchesCausality =
        filters.causality === "all" || target.causality === filters.causality;

      return (
        matchesSearch &&
        matchesScore &&
        matchesTractability &&
        matchesSafety &&
        matchesCausality
      );
    });

    // Sort
    filtered.sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];

      if (typeof aVal === "number" && typeof bVal === "number") {
        return sortDirection === "asc" ? aVal - bVal : bVal - aVal;
      }

      const aStr = String(aVal).toLowerCase();
      const bStr = String(bVal).toLowerCase();
      return sortDirection === "asc"
        ? aStr.localeCompare(bStr)
        : bStr.localeCompare(aStr);
    });

    setFilteredTargets(filtered);
  }, [targets, searchTerm, sortField, sortDirection, filters]);

  const handleSort = (field: keyof TargetData) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  const exportToCSV = () => {
    const headers = [
      "Gene",
      "Final Score",
      "Causality",
      "Tractability",
      "Safety",
      "Summary",
    ];
    const csvContent = [
      headers.join(","),
      ...filteredTargets.map((target) =>
        [
          target.gene,
          target.finalScore.toFixed(3),
          target.causality,
          target.tractability,
          target.safety,
          `"${target.summary}"`,
        ].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "targets-ranked-list.csv";
    a.click();
  };

  const getScoreColor = (score: number) => {
    if (score >= 0.9) return "text-green-600 bg-green-50";
    if (score >= 0.8) return "text-blue-600 bg-blue-50";
    if (score >= 0.7) return "text-yellow-600 bg-yellow-50";
    return "text-gray-600 bg-gray-50";
  };

  const getCausalityBadge = (causality: string) => {
    const colors = {
      High: "bg-green-100 text-green-700",
      Moderate: "bg-yellow-100 text-yellow-700",
      Low: "bg-gray-100 text-gray-700",
    };
    return colors[causality as keyof typeof colors] || colors.Low;
  };

  const getTractabilityBadge = (tractability: string) => {
    const colors = {
      Druggable: "bg-green-100 text-green-700",
      Challenging: "bg-orange-100 text-orange-700",
      Undruggable: "bg-red-100 text-red-700",
    };
    return (
      colors[tractability as keyof typeof colors] || "bg-gray-100 text-gray-700"
    );
  };

  const getSafetyBadge = (safety: string) => {
    const colors = {
      Safe: "bg-green-100 text-green-700",
      Concern: "bg-red-100 text-red-700",
      Unknown: "bg-gray-100 text-gray-700",
    };
    return colors[safety as keyof typeof colors] || colors.Unknown;
  };

  const SortButton: React.FC<{
    field: keyof TargetData;
    children: React.ReactNode;
  }> = ({ field, children }) => (
    <button
      onClick={() => handleSort(field)}
      className="flex items-center space-x-1 text-left hover:text-slate-900 transition-colors group"
    >
      <span>{children}</span>
      <ArrowUpDown className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
      {sortField === field && (
        <span className="text-blue-600">
          {sortDirection === "asc" ? "↑" : "↓"}
        </span>
      )}
    </button>
  );

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-600 to-blue-600 rounded-xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <Link
              to="/pipeline"
              className="inline-flex items-center text-teal-100 hover:text-white transition-colors mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Pipeline
            </Link>
            <h1 className="text-3xl font-bold mb-2">
              Ranked Target Candidates
            </h1>
            <p className="text-teal-100 text-lg">
              AI-discovered therapeutic targets ranked by confidence and
              druggability
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Target className="w-12 h-12 text-teal-200" />
            <div className="text-right">
              <div className="text-2xl font-bold">{filteredTargets.length}</div>
              <div className="text-sm text-teal-200">Candidate Targets</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search genes or descriptions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center px-4 py-2 border border-slate-300 rounded-md hover:bg-slate-50 transition-colors"
            >
              <Filter className="w-4 h-4 mr-2" />
              Filters
              <ChevronDown
                className={`w-4 h-4 ml-2 transform transition-transform ${
                  showFilters ? "rotate-180" : ""
                }`}
              />
            </button>
          </div>
          <button
            onClick={exportToCSV}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </button>
        </div>

        {/* Filter Panel */}
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="border-t border-slate-200 pt-4 mt-4"
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Score Threshold
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={filters.scoreThreshold}
                  onChange={(e) =>
                    setFilters({
                      ...filters,
                      scoreThreshold: parseFloat(e.target.value),
                    })
                  }
                  className="w-full"
                />
                <div className="text-xs text-slate-500 mt-1">
                  {filters.scoreThreshold.toFixed(1)}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Tractability
                </label>
                <select
                  value={filters.tractability}
                  onChange={(e) =>
                    setFilters({ ...filters, tractability: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All</option>
                  <option value="Druggable">Druggable</option>
                  <option value="Challenging">Challenging</option>
                  <option value="Undruggable">Undruggable</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Safety
                </label>
                <select
                  value={filters.safety}
                  onChange={(e) =>
                    setFilters({ ...filters, safety: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All</option>
                  <option value="Safe">Safe</option>
                  <option value="Concern">Concern</option>
                  <option value="Unknown">Unknown</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Causality
                </label>
                <select
                  value={filters.causality}
                  onChange={(e) =>
                    setFilters({ ...filters, causality: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All</option>
                  <option value="High">High</option>
                  <option value="Moderate">Moderate</option>
                  <option value="Low">Low</option>
                </select>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Results Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
          <h3 className="text-lg font-semibold text-slate-900">
            Target Results ({filteredTargets.length} of {targets.length})
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  <SortButton field="rank">Rank</SortButton>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  <SortButton field="gene">Gene</SortButton>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  <SortButton field="finalScore">Final Score</SortButton>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  <SortButton field="causality">Causality</SortButton>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  <SortButton field="tractability">Tractability</SortButton>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  <SortButton field="safety">Safety</SortButton>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Key Features
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Summary
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredTargets.map((target, index) => (
                <motion.tr
                  key={target.gene}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="hover:bg-slate-50 transition-colors duration-150"
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-slate-900">
                      #{target.rank}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-mono font-semibold text-slate-900 text-lg">
                      {target.gene}
                    </div>
                    <div className="text-sm text-slate-500">
                      Confidence: {(target.confidence * 100).toFixed(0)}%
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      <div
                        className={`inline-flex items-center px-3 py-1 rounded-full font-medium ${getScoreColor(
                          target.finalScore
                        )}`}
                      >
                        {target.finalScore.toFixed(3)}
                      </div>
                      <div className="w-20 bg-slate-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${target.finalScore * 100}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getCausalityBadge(
                        target.causality
                      )}`}
                    >
                      {target.causality === "High" && (
                        <CheckCircle className="w-3 h-3 mr-1" />
                      )}
                      {target.causality === "Moderate" && (
                        <AlertCircle className="w-3 h-3 mr-1" />
                      )}
                      {target.causality === "Low" && (
                        <Shield className="w-3 h-3 mr-1" />
                      )}
                      {target.causality}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 text-xs rounded ${getTractabilityBadge(
                        target.tractability
                      )}`}
                    >
                      {target.tractability}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 py-1 text-xs rounded ${getSafetyBadge(
                        target.safety
                      )}`}
                    >
                      {target.safety}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {target.keyFeatures.slice(0, 2).map((feature) => (
                        <span
                          key={feature}
                          className="px-2 py-1 text-xs bg-blue-50 text-blue-700 rounded border border-blue-200"
                          title={feature}
                        >
                          {feature}
                        </span>
                      ))}
                      {target.keyFeatures.length > 2 && (
                        <span
                          className="px-2 py-1 text-xs bg-slate-100 text-slate-600 rounded cursor-help"
                          title={target.keyFeatures.slice(2).join(", ")}
                        >
                          +{target.keyFeatures.length - 2}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 max-w-xs">
                    <p className="text-sm text-slate-600 line-clamp-2">
                      {target.summary}
                    </p>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Link
                      to={`/targets/${target.gene}`}
                      className="inline-flex items-center px-3 py-2 text-sm font-medium 
                               text-white bg-blue-600 rounded-md hover:bg-blue-700 
                               transition-colors duration-200"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View Dossier
                    </Link>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredTargets.length === 0 && (
          <div className="text-center py-12">
            <Target className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-700 mb-2">
              No targets found
            </h3>
            <p className="text-slate-600">
              Try adjusting your search criteria or filters.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TargetsTop;
