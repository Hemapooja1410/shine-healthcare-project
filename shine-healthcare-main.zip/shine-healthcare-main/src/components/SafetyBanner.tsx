import React, { useState } from 'react';
import { AlertTriangle, X } from 'lucide-react';

const SafetyBanner: React.FC = () => {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="bg-red-50 border-b border-red-200 px-4 py-3">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <AlertTriangle className="h-5 w-5 text-red-600" />
          <div>
            <span className="font-semibold text-red-800">Prototype — Not for Clinical Use</span>
            <span className="text-red-700 ml-2">
              Data are demo/synthetic unless otherwise noted. For research purposes only.
            </span>
          </div>
        </div>
        <button
          onClick={() => setIsVisible(false)}
          className="text-red-600 hover:text-red-800 transition-colors"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default SafetyBanner;