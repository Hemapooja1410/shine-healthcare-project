import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Dashboard from "./components/Dashboard";
import TargetDetail from "./components/TargetDetail";
import Header from "./components/Header";
import SafetyBanner from "./components/SafetyBanner";
import "./App.css";
import Pipeline from "./components/Pipeline";

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <SafetyBanner />
        <Header />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/targets/top" element={<Dashboard />} />
            <Route path="/targets/:gene" element={<TargetDetail />} />
            <Route path="/pipeline" element={<Pipeline />} />
            {/* <Route path="/settings" element={<Settings />} /> */}
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
