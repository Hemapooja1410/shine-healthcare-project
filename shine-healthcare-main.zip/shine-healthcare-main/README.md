# AI Target Identification & Validation Platform

A production-ready hackathon application demonstrating how AI can rank, validate, and explain disease-related protein/gene targets for drug discovery researchers.

## 🎯 Overview

This platform combines machine learning predictions with comprehensive biological evidence to identify and prioritize therapeutic targets. It features a FastAPI backend for data processing and target scoring, plus a modern React frontend for interactive exploration of results.

## 🚀 Quick Start

### Prerequisites
- Python 3.8+ (for backend)
- Node.js 16+ (for frontend)

### Backend Setup
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

Backend will be available at: http://localhost:8000

### Frontend Setup
```bash
npm install
npm run dev
```

Frontend will be available at: http://localhost:5173

## 🏗️ Architecture

### Backend (FastAPI)
- **High-performance API** with startup data preloading
- **Target ranking endpoint** (`/targets/top`)
- **Detailed target cards** (`/targets/{gene}/card`)
- **Search functionality** for gene discovery
- **Comprehensive dossiers** with markdown rendering

### Frontend (React + TypeScript)
- **Interactive dashboard** with real-time search
- **Responsive design** with Tailwind CSS
- **Smooth animations** using Framer Motion
- **Professional data visualization**
- **Detailed target exploration** with markdown dossiers

## 📊 Demo Data

The platform includes mock data for demonstration:

### Targets (`backend/data/targets_scored.csv`)
- **CYP2C19** - High-confidence druggable target (score: 0.905)
- **EGFR** - Validated oncology target (score: 0.91)
- **APP** - Alzheimer's target with safety concerns (score: 0.79)
- **BACE1** - Challenging druggability profile (score: 0.80)
- **PCSK9** - Validated cardiovascular target (score: 0.90)

### Dossiers (`backend/dossiers/`)
Comprehensive target analysis including:
- Genetic evidence and validation
- Omics support and biomarkers
- Functional screening results
- Safety and toxicity profiles
- Druggability assessment
- Recommended next steps

## 🎨 Features

### Core Functionality
- **AI-powered target ranking** with explainable scores
- **Multi-criteria filtering** by confidence and druggability
- **Real-time search** across targets and descriptions
- **Detailed target dossiers** with scientific evidence
- **Export and sharing** capabilities
- **Responsive design** for all devices

### User Experience
- **Professional scientific interface** with clean typography
- **Intuitive navigation** and clear information hierarchy  
- **Smooth animations** and micro-interactions
- **Accessible design** with proper contrast ratios
- **Fast loading** with optimized data handling

## 🔧 Technical Details

### Backend Technologies
- **FastAPI** - Modern Python web framework
- **Pandas** - Data processing and analysis
- **Uvicorn** - ASGI server for high performance

### Frontend Technologies  
- **React 18** - Modern UI framework
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first styling
- **Framer Motion** - Smooth animations
- **React Markdown** - Dossier rendering
- **React Router** - Navigation

### Performance Optimizations
- **Startup data preloading** for instant API responses
- **Memory caching** of frequently accessed data
- **Optimized bundle size** with tree shaking
- **Responsive images** and efficient asset loading

## 🎪 Demo Flow

1. **Dashboard View** - Browse AI-ranked targets with confidence scores
2. **Search & Filter** - Find specific targets or browse by criteria  
3. **Target Details** - Click any target to view comprehensive dossier
4. **Scientific Evidence** - Review genetic, functional, and safety data
5. **Export Results** - Download findings for further analysis

## 🏆 Hackathon Ready

This application is specifically designed for demonstration:

- **Easy setup** - Single command startup for both backend and frontend
- **Mock data included** - No external dependencies required
- **Professional UI** - Impressive visual design for judges
- **Clear value proposition** - Demonstrates AI acceleration of drug discovery
- **Extensible architecture** - Easy to add new features during hackathon

## 📈 Future Enhancements

- Integration with public biomedical databases (ChEMBL, UniProt)
- Real-time ML model predictions
- Collaborative target annotation
- Advanced visualization and analytics
- API integration with laboratory systems

## 🤝 Contributing

This project serves as a foundation for drug discovery AI applications. Contributions welcome for:
- Additional target scoring algorithms
- Enhanced visualization components  
- Integration with biological databases
- Performance optimizations
- Mobile app development

---

*Built with modern web technologies for the future of drug discovery* 🧬✨