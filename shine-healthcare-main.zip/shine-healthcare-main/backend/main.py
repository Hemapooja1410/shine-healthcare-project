from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import os
from typing import Optional, List, Dict, Any
import uvicorn

app = FastAPI(
    title="AI Target Identification & Validation API",
    description="API for ranking and validating disease-related protein/gene targets",
    version="1.0.0"
)

# CORS middleware for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global data storage - preloaded at startup for performance
targets_df = None
dossier_cache = {}

def load_data():
    """Preload all data at startup for optimal performance"""
    global targets_df, dossier_cache
    
    # Load targets CSV data
    csv_path = "data/targets_scored.csv"
    if os.path.exists(csv_path):
        targets_df = pd.read_csv(csv_path)
        print(f"Loaded {len(targets_df)} targets from CSV")
    else:
        print(f"Warning: {csv_path} not found, using mock data")
        targets_df = create_mock_data()
    
    # Preload all dossier files
    dossier_dir = "dossiers"
    if os.path.exists(dossier_dir):
        for filename in os.listdir(dossier_dir):
            if filename.endswith('.md'):
                gene_name = filename.replace('.md', '')
                file_path = os.path.join(dossier_dir, filename)
                with open(file_path, 'r', encoding='utf-8') as f:
                    dossier_cache[gene_name.upper()] = f.read()
                print(f"Cached dossier for {gene_name}")

def create_mock_data():
    """Create mock data if CSV file doesn't exist"""
    return pd.DataFrame([
        {
            'gene': 'CYP2C19',
            'ml_score': 0.89,
            'tps': 0.92,
            'final_score': 0.905,
            'flags': 'HIGH_CONFIDENCE,DRUGGABLE',
            'top_features': 'genetic_evidence,omics_support,safety_profile',
            'summary': 'Cytochrome P450 enzyme with strong genetic evidence for drug metabolism disorders. High tractability for small molecule inhibition.'
        },
        {
            'gene': 'EGFR',
            'ml_score': 0.94,
            'tps': 0.88,
            'final_score': 0.91,
            'flags': 'HIGH_CONFIDENCE,VALIDATED_TARGET',
            'top_features': 'clinical_evidence,functional_screens,druggability',
            'summary': 'Epidermal growth factor receptor, well-validated oncology target with multiple approved therapeutics and strong clinical evidence.'
        },
        {
            'gene': 'APP',
            'ml_score': 0.76,
            'tps': 0.82,
            'final_score': 0.79,
            'flags': 'MODERATE_CONFIDENCE,SAFETY_CONCERN',
            'top_features': 'genetic_association,pathway_analysis,biomarker_potential',
            'summary': 'Amyloid precursor protein implicated in Alzheimer\'s disease. Moderate confidence with safety considerations for therapeutic intervention.'
        },
        {
            'gene': 'BACE1',
            'ml_score': 0.85,
            'tps': 0.75,
            'final_score': 0.80,
            'flags': 'HIGH_CONFIDENCE,CHALLENGING_DRUGGABILITY',
            'top_features': 'mechanistic_evidence,animal_models,selectivity_challenges',
            'summary': 'Beta-secretase 1, key enzyme in amyloid processing. Strong mechanistic evidence but challenging selectivity profile.'
        },
        {
            'gene': 'PCSK9',
            'ml_score': 0.91,
            'tps': 0.89,
            'final_score': 0.90,
            'flags': 'HIGH_CONFIDENCE,DRUGGABLE,VALIDATED_TARGET',
            'top_features': 'genetic_validation,clinical_success,safety_profile',
            'summary': 'Proprotein convertase subtilisin/kexin type 9, validated target for cholesterol management with approved therapeutics.'
        }
    ])

@app.on_event("startup")
async def startup_event():
    """Initialize data on startup"""
    load_data()

@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "message": "AI Target Identification & Validation API",
        "status": "active",
        "targets_loaded": len(targets_df) if targets_df is not None else 0
    }

@app.get("/targets/top")
async def get_top_targets(n: Optional[int] = 10):
    """Get top N scored targets with flags and summary"""
    if targets_df is None:
        raise HTTPException(status_code=500, detail="Target data not loaded")
    
    # Sort by final_score descending and take top N
    top_targets = targets_df.nlargest(n, 'final_score')
    
    # Convert to list of dictionaries for JSON response
    results = []
    for _, row in top_targets.iterrows():
        results.append({
            "gene": row['gene'],
            "ml_score": float(row['ml_score']),
            "tps": float(row['tps']),
            "final_score": float(row['final_score']),
            "flags": row['flags'].split(',') if isinstance(row['flags'], str) else [],
            "top_features": row['top_features'].split(',') if isinstance(row['top_features'], str) else [],
            "summary": row['summary']
        })
    
    return {
        "targets": results,
        "total_count": len(targets_df),
        "returned_count": len(results)
    }

@app.get("/targets/{gene}/card")
async def get_target_card(gene: str):
    """Get full target details including dossier"""
    if targets_df is None:
        raise HTTPException(status_code=500, detail="Target data not loaded")
    
    # Find target in dataframe (case-insensitive)
    target_row = targets_df[targets_df['gene'].str.upper() == gene.upper()]
    
    if target_row.empty:
        raise HTTPException(status_code=404, detail=f"Target {gene} not found")
    
    # Get target data
    target_data = target_row.iloc[0]
    
    # Get dossier if available
    dossier_content = dossier_cache.get(gene.upper(), "")
    
    # Prepare response
    result = {
        "gene": target_data['gene'],
        "scores": {
            "ml_score": float(target_data['ml_score']),
            "tps": float(target_data['tps']),
            "final_score": float(target_data['final_score'])
        },
        "flags": target_data['flags'].split(',') if isinstance(target_data['flags'], str) else [],
        "top_features": target_data['top_features'].split(',') if isinstance(target_data['top_features'], str) else [],
        "summary": target_data['summary'],
        "dossier": dossier_content,
        "has_dossier": bool(dossier_content)
    }
    
    return result

@app.get("/targets/search")
async def search_targets(q: str):
    """Search targets by gene name"""
    if targets_df is None:
        raise HTTPException(status_code=500, detail="Target data not loaded")
    
    # Case-insensitive search
    matches = targets_df[targets_df['gene'].str.contains(q, case=False, na=False)]
    
    results = []
    for _, row in matches.iterrows():
        results.append({
            "gene": row['gene'],
            "final_score": float(row['final_score']),
            "summary": row['summary'][:100] + "..." if len(row['summary']) > 100 else row['summary']
        })
    
    return {
        "query": q,
        "results": results,
        "count": len(results)
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)