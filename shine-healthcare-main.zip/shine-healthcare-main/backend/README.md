# AI Target Identification Backend

FastAPI backend for the AI Target Identification & Validation Platform.

## Features

- **High-Performance API:** Optimized data loading with startup preloading
- **Target Ranking:** ML-scored targets with validation flags
- **Detailed Dossiers:** Comprehensive target analysis in markdown format
- **Search Functionality:** Gene name search with fuzzy matching
- **CORS Support:** Ready for frontend integration

## Quick Start

1. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run Development Server:**
   ```bash
   uvicorn main:app --reload
   ```

3. **Access API:**
   - API: http://localhost:8000
   - Docs: http://localhost:8000/docs
   - ReDoc: http://localhost:8000/redoc

## API Endpoints

### `GET /targets/top?n=10`
Returns top N scored targets with flags and summary.

**Response:**
```json
{
  "targets": [
    {
      "gene": "CYP2C19",
      "ml_score": 0.89,
      "tps": 0.92,
      "final_score": 0.905,
      "flags": ["HIGH_CONFIDENCE", "DRUGGABLE"],
      "top_features": ["genetic_evidence", "omics_support"],
      "summary": "Cytochrome P450 enzyme with strong genetic evidence..."
    }
  ],
  "total_count": 10,
  "returned_count": 10
}
```

### `GET /targets/{gene}/card`
Returns full target details including dossier.

**Example:** `/targets/CYP2C19/card`

### `GET /targets/search?q=EGFR`
Search targets by gene name.

## Data Structure

### CSV Format (`data/targets_scored.csv`)
- `gene`: Gene symbol
- `ml_score`: Machine learning confidence score (0-1)
- `tps`: Target priority score (0-1)  
- `final_score`: Combined final score (0-1)
- `flags`: Comma-separated validation flags
- `top_features`: Key evidence features
- `summary`: Brief target description

### Dossier Format (`dossiers/{GENE}.md`)
Comprehensive markdown reports including:
- Genetic evidence
- Omics support
- Functional validation
- Safety assessment
- Tractability analysis
- Recommended experiments

## Performance Optimizations

- **Startup Preloading:** All data loaded into memory at startup
- **Cached Dossiers:** Markdown files cached in memory
- **Fast Pandas Operations:** Optimized dataframe queries
- **Async Endpoints:** Non-blocking request handling

## Development Notes

The API uses mock data for demonstration purposes. In production, this would connect to:
- Target scoring ML models
- Biomedical databases (ChEMBL, STRING, etc.)
- Literature mining services
- Clinical trial databases